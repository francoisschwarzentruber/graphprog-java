/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author proprietaire
 */
public class TurtleEnvironment extends JPanel {
    private Color fond_couleur = new Color(192, 192, 255);
    

    private ImageIcon imgTurtle;
    
    private ArrayList<Point> points;
    
    public double turtle_x = 0;
    public double turtle_y = 0;
    public double turtle_direction_angle;
    
    
    private Rectangle rectangle;
    private Challenge challenge = null;
    private boolean turtle_visible = true;
    
    public TurtleEnvironment()
    {
        imgTurtle = Images.get( "/graphprog/resources/turtle.png" );
        points = new ArrayList<Point>();
        
        drawing_clear();
    }
    
    

    public void NoChallenge()
    {
        challenge = null;
        repaint();
    }
    
    
    public boolean isChallenge()
    {
        return(challenge != null);
        
    }
    
    public void reset()
    {
        drawing_clear();
    }
    
    private void rectangle_takecare_about_challenge()
    {
        if(challenge == null)
            return;
        
        Point point_en_haut_a_gauche = challenge.WhatTheTurtleHasToDraw_getImageIconOriginInImage().getLocation();
        point_en_haut_a_gauche.x = -point_en_haut_a_gauche.x;
        point_en_haut_a_gauche.y = -point_en_haut_a_gauche.y;
        
        rectangle.add(point_en_haut_a_gauche);
        
        Point point_en_bas_a_droite = point_en_haut_a_gauche.getLocation();
        point_en_bas_a_droite.x += challenge.WhatTheTurtleHasToDraw_getImageIcon().getIconWidth();
        point_en_bas_a_droite.y += challenge.WhatTheTurtleHasToDraw_getImageIcon().getIconHeight();
        rectangle.add(point_en_bas_a_droite);
        
    }
    
    public void setChallenge(Challenge challenge)
    {
        this.challenge = challenge;
        rectangle_takecare_about_challenge();
             
        repaint();
    }
        
    private float NbPixelsOfAColor(BufferedImage img, Color c)
    {
        int count = 0;
        for(int x = 0; x < img.getWidth(); x++)
        {
            for(int y = 0; y < img.getHeight(); y++)
            {
                if(img.getRGB(x, y) == c.getRGB())
                {
                    count++;
                }
            }
            
        }
        
        return (float) count;
        
    }
    
    
    
    public boolean Challenge_succeed()
    {
        
        BufferedImage img;
        img = new BufferedImage(getWidth(), getHeight(), 
                                BufferedImage.TYPE_INT_RGB);
        
        
        Graphics g = img.createGraphics();
        
        
        draw_clear_screen(g);
        
        draw_affine_transform(g);
        draw_points(g);
        draw_WhatTheTurtleHasToDraw(g);
        
        if(NbPixelsOfAColor(img, Color.BLACK) / NbPixelsOfAColor(img, Color.RED) > 0.2)
        {
            return false;
        }
        
        
        draw_clear_screen(g);
        draw_WhatTheTurtleHasToDraw(g);
        draw_points(g);
        
        if(NbPixelsOfAColor(img, Color.BLACK) == 0)
             return false;
        
        if(NbPixelsOfAColor(img, Color.RED) / NbPixelsOfAColor(img, Color.BLACK) > 0.25)
        {
            return false;
        }
              
        
        return true;
        
    }
    
    
        
    public void drawing_clear()
    {
        Point point = new Point(round(turtle_x), round(turtle_y));
        points.clear();
        points.add(point);
        
        rectangle = new Rectangle();
        rectangle.add(point);
        rectangle.add(new Point(round(turtle_x - imgTurtle.getIconWidth()),
                      round(turtle_y)));
                
        rectangle_takecare_about_challenge();
    }
    
    
    
    public void drawing_polygon_points_add(Point point)
    {
        points.add(point);
        rectangle.add(point);
    }
    
    
    public void drawing_polygon_points_add(double x, double y)
    {
        drawing_polygon_points_add(new Point(round(x), round(y)));    
    }
    
    private void draw_clear_screen(Graphics g)
    {
         g.setColor(fond_couleur);
         g.fillRect(0, 0, getWidth(), getHeight());
    }
    
    
    private void draw_points(Graphics g)
    {
        g.setColor(Color.BLACK);
        for(int i = 0; i < points.size() - 1; i++)
        {
            g.drawLine(points.get(i).x, points.get(i).y,
                       points.get(i+1).x, points.get(i+1).y);
        }
    }
    
    
    
    private void draw_turtle(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        
        
        AffineTransform xform;
        
        xform = new AffineTransform();
        xform.setToIdentity();
        xform.setToTranslation(turtle_x, turtle_y);
        xform.rotate(turtle_direction_angle);
        xform.translate(-imgTurtle.getIconWidth(), -imgTurtle.getIconHeight() / 2);
        
        g2.drawImage(imgTurtle.getImage(), xform, this);
                     
    
    }
        
    private void draw_affine_transform(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        
        AffineTransform xform;
        xform = new AffineTransform();
        xform.setToIdentity();
        
        
        double rapport = 1.0;
        
        if((rectangle.getMaxX() - rectangle.getMinX()) > getWidth())
                rapport = getWidth() / (rectangle.getMaxX() - rectangle.getMinX());
        
        if((rectangle.getMaxY() - rectangle.getMinY()) > getHeight())
                rapport = Math.min(rapport,
                                   getHeight()
                                          / (rectangle.getMaxY() - rectangle.getMinY()));
                
        g2.translate(+ getWidth() / 2,
                     + getHeight() / 2);
        
        g2.scale(rapport, rapport);
        
        g2.translate(- (rectangle.getMaxX() + rectangle.getMinX()) / 2, 
                     - (rectangle.getMaxY() + rectangle.getMinY()) / 2); 
    }
    
    
    
    public void draw_WhatTheTurtleHasToDraw(Graphics g)
    {
        if(challenge != null)
        {
            ImageIcon img = challenge.WhatTheTurtleHasToDraw_getImageIcon();
            Point p = challenge.WhatTheTurtleHasToDraw_getImageIconOriginInImage();
            g.drawImage(img.getImage(), -p.x, -p.y, this);
        }
        
    }
    
    public void antialiasing(Graphics2D g2)
    {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
        RenderingHints.VALUE_RENDER_QUALITY);
    }
    
    
    public void draw(Graphics g)
    {
            Graphics2D g2 = (Graphics2D) g;
            
            
            AffineTransform atsav = g2.getTransform();
            
            
            draw_clear_screen(g);
            
            draw_affine_transform(g);
            draw_WhatTheTurtleHasToDraw(g);
            draw_points(g);
            
            antialiasing(g2);
            
            if(turtle_visible)
                draw_turtle(g);
            
            g2.setTransform(atsav);

    }
    
    
    
    
    private int round(double a)
    {
        return ((int) Math.round(a));
    }
    
    
     @Override
     protected void paintComponent(Graphics g)
     {
        draw(g);
     }
     
     
     
     public void turtle_setvisible(boolean visible)
     {
         turtle_visible = visible;
         repaint();
     }
     
      public boolean turtle_isvisible()
     {
         return turtle_visible;
     }
}
