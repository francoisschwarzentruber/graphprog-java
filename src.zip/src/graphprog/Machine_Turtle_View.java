/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

/**
 *
 * @author proprietaire
 */
public class Machine_Turtle_View {

    private GraphprogView gpv; 
    
    
    public Machine_Turtle_View(GraphprogView gpv)
    {
        this.gpv = gpv;
    }
    
    
    public void Inform_Execute()
    {
        gpv.Inform_Execute();
    }
    
    
    public void Inform_Stop()
    {
        gpv.Inform_Stop();
    }
    
}
