/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.ArrayList;


/**
 *
 * @author proprietaire
 */
public class BrickWithoutSequence extends Brick {
    
    
    
    
    
    public BrickWithoutSequence(BrickType bt, int children_count)
    {
        super(bt, children_count);
        
    }
    
    
    
    
    @Override
    public void position_calculer()
    {
        int y = getPosy();
        int i = 0;
        
        brickchildrensocketrect = new ArrayList<Rectangle>();
        brick_polygon = new Polygon();
        //brick_polygon.addPoint(getPosx(), getPosy());
        brick_polygon.addPoint(getPosx() + Brick_width, y);
        
        if(brickchildren.size()==0)
        {
            y += Brick_height_oneline;
        }
        else
        {
            y += Brick_height_littlespace;
        }
        brick_polygon.addPoint(getPosx() + Brick_width, y);
        
        for(i = 0; i<brickchildren.size(); i++)
           {
                //brick_polygon.addPoint(getPosx() + Brick_width_interior, y);
                child_setStringPos(i, new Point(getPosx() + 5,
                                      y + 15));
                
                if(!child_is_empty(i))
                {
                    child_get(i).move(getPosx() + Brick_width_interior, y);
                }
                
                brickchildrensocketrect.add(new Rectangle(getPosx() + Brick_width_interior + Socket_X,
                                                          y + Socket_Y,
                                                          Socket_Width, child_height(i) + Socket_HeightMore));
                
                child_getBrickType(i).ShapeTopToBottom(brick_polygon,
                                                       getPosx() + Brick_width_interior,
                                                       y,
                                                       child_height(i));
                y += child_height(i);
                //brick_polygon.addPoint(getPosx() + Brick_width_interior, y);
                brick_polygon.addPoint(getPosx() + Brick_width, y);
                y += Brick_height_littlespace;
                brick_polygon.addPoint(getPosx() + Brick_width, y);
           }
        
        //brick_polygon.addPoint(getPosx(), y);        
        //brick_polygon.addPoint(getPosx(), getPosy());
        
        
        height = y - getPosy();
        
        getBrickType().ShapeBottomToTop(brick_polygon,
                                        getPosx(),
                                        getPosy(),
                                        height);
        
        totalheight = height;
        
    }
    
    @Override
    public void draw(Graphics g)
    {
        g.setColor(color);
        g.fillPolygon(brick_polygon);
        g.setColor(Color.GRAY);
        g.drawPolygon(brick_polygon);
        
        g.setColor(getColorInterior());
        g.fillRect(getPosx()+3, getPosy()+3, getWidthInterior()-6, getHeight()-6);
        
        
        g.setColor(Color.BLACK);
        for(int i = 0; i<brickchildren.size(); i++)
        {
            Point pos = child_getStringPos(i);
            g.drawString(child_getString(i), pos.x, pos.y);
        }
    }

    
}
