/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickInteger extends BrickWithText {

    private int i = 0;
    
    public LIBrickInteger(int i)
    {   
        super(BrickType.INTEGER,  String.valueOf(i));
        this.i = i;
    }
    
    
    public int getValue()
    {
        return i;
    }
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        mt.ValuePush(i);
        return null;
    }
    
    
            @Override
        public void brick_sauvegarder(BufferedWriter writer) throws IOException
        {
            writer.write("(int "); 
            writer.write(String.valueOf(getValue()));
            writer.write(")");
        }    
    
}
