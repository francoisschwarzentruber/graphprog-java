/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Polygon;

/**
 *
 * @author proprietaire
 */
public class BrickWithText extends Brick {
    private String text = null;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    
    
    
    public BrickWithText(BrickType bt, String text)
    {
        super(bt, 0);
        
        if(text == null)
        {
            return;
        }
        setText(text);
        setBrick_width_interior(20);
        setColor(Color.WHITE);
    }
    
    @Override
    public void position_calculer()
    {
        brick_polygon = new Polygon();
        brick_polygon.addPoint(getPosx() + Brick_width, getPosy());
        brick_polygon.addPoint(getPosx() + Brick_width, getPosy() + Brick_height_oneline);
        getBrickType().ShapeBottomToTop(brick_polygon, getPosx(), getPosy(), Brick_height_oneline);
        
        totalheight = Brick_height_oneline;
        height = Brick_height_oneline;
    }
    
    
    @Override
    public void Width_Adapt(FontMetrics fm)
    {
        int nw = getWidthInterior();
        
        nw = Math.max(nw, fm.stringWidth(getText()) + 16);
        
        setBrick_width_interior(nw);
        position_calculer();
    }
    
    @Override
    public void draw(Graphics g)
    {
        g.setColor(color);
        g.fillPolygon(brick_polygon);
        g.setColor(Color.BLACK);
        g.drawPolygon(brick_polygon);
        
        g.setColor(Color.BLACK);
        g.drawString(text, getPosx() + 9,getPosy() + 20);
    }
    
    
}
