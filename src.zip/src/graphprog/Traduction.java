/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public  class Traduction {
    public static String traduire(String mot) throws IOException {
        try {
            return java.util.ResourceBundle.getBundle("resources/Challenges").getString(mot);
        } catch (Exception ex) {
            //throw new IOException("impossible to translate " + mot);
            return mot;
        }
    }
}
