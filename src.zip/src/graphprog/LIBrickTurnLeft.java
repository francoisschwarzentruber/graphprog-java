/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

/**
 *
 * @author proprietaire
 */
public class LIBrickTurnLeft extends LIBrickTurn {
     public LIBrickTurnLeft()
     {
         super(-Math.PI/2);
     }
}
