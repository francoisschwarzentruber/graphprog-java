/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Area;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author proprietaire
 */
public class Brick {

    

    
    
    protected int Brick_width = 80;
    protected int Brick_Encoche_Socket = 16;
    static protected int Brick_height_oneline = 24;//32
    protected int Socket_Height_For_SequenceOfAction = 6;//8
    protected int Brick_height_littlespace = 2;//8
    
    protected int Brick_width_interior = 64;
    
    protected int Socket_X = -4;
    protected int Socket_Y = -3;
    protected int Socket_HeightMore = 6;
    protected int Socket_Width = 14;
    
    private BrickType brickType;

    public BrickType getBrickType() {
        return brickType;
    }

    public void setBrickType(BrickType brickType) {
        this.brickType = brickType;
    }
    
    private int posx, posy;
    protected java.awt.Color color;

    
    static public void setBricks_OneLine_Height(int Brick_Height)
    {
        Brick_height_oneline = Brick_Height;
    }
    
    public void setBrick_width(int Brick_width) {
        this.Brick_width = Brick_width;
        this.Brick_width_interior = Brick_width - Brick_Encoche_Socket;
    }
    
    public void setBrick_width_interior(int Brick_width_interior) {
        setBrick_width(Brick_width_interior + Brick_Encoche_Socket);
    }
    
    public void setColor(Color color) {
        this.color = color;
    }
    

    protected Color getColorInterior()
    {
        return color.brighter();
        
    }
    
    public int getPosx() {
        return posx;
    }

    public int getPosy() {
        return posy;
    }

    
    protected ArrayList<Brick> brickchildren;
    protected ArrayList<Rectangle> brickchildrensocketrect;
    protected ArrayList<String> brickchildrenstring;
    protected ArrayList<Point> brickchildrenstringpos;
    protected ArrayList<BrickType> brickchildrenbricktype;
    protected Polygon brick_polygon;
    
    protected int height = 0;
    protected int totalheight = 0;
    
    private Brick father_brick = null;
    private int father_i;

    
    public int getNbChildren()
    {
        return brickchildren.size();
    }
    
    
    public boolean xy_in_brick(int x, int y)
    {
        return brick_polygon.contains(x, y);
    }

    
    public int getWidthInterior()
    {
        return Brick_width_interior;    
    
    }
    
    
    public int getTotalHeight() {
        return totalheight;
    }
    
    
    public int getHeight() {
        return height;
    }

    void brick_sauvegarder(BufferedWriter writer)  throws IOException {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
    
    protected void brick_sauvegarder_tenter(Brick b, BufferedWriter writer) throws IOException
    {
        if(b == null)
        {
            writer.write(" nobrick ");
        }
        else
        {
            b.brick_sauvegarder(writer);
        }
    }

    String execute_informations_supplementaires_get(Machine_Turtle aThis)
    {
        return "";
    }

    Polygon getPolygon() {
        return brick_polygon;
    }

    Point getPos() {
        return new Point(getPosx(), getPosy());
    }

    Brick getTopLevelFather() {
        if(father_brick == null)
        {
            return this;
        }
        else
        {
            return father_brick.getTopLevelFather();
        }
    }

    Area getWholeArea() {
       Area wa = new Area();
       wa.add(new Area(brick_polygon));
       for(int i = 0; i<brickchildren.size(); i++)
       {
            if(brickchildren.get(i) != null)
               wa.add( brickchildren.get(i).getWholeArea());
       }
       return wa;
    }


    
    private void setfather(Brick f, int fi)
    {
         father_brick = f;
         father_i = fi;
    }
    
    
    public boolean child_is_empty(int i)
    {
        return (brickchildren.get(i) == null);
    }
    
    
    public Brick child_get(int i)
    {
            return brickchildren.get(i);
    }
    
    public void child_set(int i, Brick b)
    {
        if(child_get(i) != null)
        {
             child_get(i).disconnect();
        }
        
        if(b!=null)
        {
             b.disconnect();
        }
        
        brickchildren.set(i, b);
        
        if(b != null)
        {
            b.setfather(this, i);
        }
        position_calculer();
    }
    
    
    public void child_setString(int i, String s)
    {
        brickchildrenstring.set(i, s);
    }
    
    public String child_getString(int i)
    {
        return brickchildrenstring.get(i);
    }
    
    
    public Point child_getStringPos(int i)
    {
        return brickchildrenstringpos.get(i);
    }
    
    
    public void child_setStringPos(int i, Point p)
    {
        brickchildrenstringpos.set(i, p);
    }
    
    
    public BrickType child_getBrickType(int i)
    {
        return brickchildrenbricktype.get(i);
    }    
    
    public void child_setBrickType(int i, BrickType bt)
    {
        brickchildrenbricktype.set(i, bt);
    }
    
    
    public void child_set_null(int i)
    {
        brickchildren.set(i, null);
        position_calculer();
    }
    
    
    
    public int child_height(int i)
    {
        if(child_is_empty(i))
        {
            return Brick_height_oneline;
        }
        else
        {
            return child_get(i).getTotalHeight();
        }
    }
    
    
    public Brick(BrickType bt)
    {
        brickchildren = new ArrayList<Brick>();
        brickchildrensocketrect = new ArrayList<Rectangle>();
        brick_polygon = new Polygon();
        brickchildrenstring = new ArrayList<String>();
        brickchildrenstringpos = new ArrayList<Point>();
        brickchildrenbricktype = new ArrayList<BrickType>();
        
        setBrickType(bt);
        move(0, 0);
    }
    
    
    public Brick(BrickType bt, int children_count)
    {
       brickchildren = new ArrayList<Brick>();
       brickchildrensocketrect = new ArrayList<Rectangle>();
       brickchildrenstring = new ArrayList<String>();
       brickchildrenstringpos = new ArrayList<Point>();
       brickchildrenbricktype = new ArrayList<BrickType>();
       
       setBrickType(bt);
       
       for(int i = 0; i<children_count; i++)
       {
           brickchildren.add(null);
           brickchildrensocketrect.add(new Rectangle(0, 0, 0, 0));
           brickchildrenstring.add("");
           brickchildrenstringpos.add(new Point(0, 0));
           brickchildrenbricktype.add(BrickType.INSTRUCTION);
            //brickchildren.set(i, null);
       }
       
       move(0, 0);
    }
    
    
    public void move(int newposx, int newposy)
    {
        posx = newposx;
        posy = newposy;
        position_calculer();
    }
    
    
    public void move(Point p)
    {
        move(p.x, p.y);
    }
    
    
    
    public void position_calculer()
    {

    }
    
    public void draw(Graphics g)
    {     
     
    }
    
    

    protected void surimprimer_texte(Graphics g, String s)
    {
        int y = getPosy() + getHeight() / 2;
        int x = getPosx() + 8;
        
        Font f = new Font("Tahoma", Font.BOLD, 28);
                
        g.setColor(Color.red);
        g.setFont(f);
        g.drawString(s, x, y);
        
    }
    
    
    
    public void draw_socketcursor(Graphics g, int num_socket)
    {
        Rectangle r = brickchildrensocketrect.get(num_socket);
        g.setColor(Color.GRAY);
        g.fill3DRect(r.x, r.y, r.width, r.height, true);
    }
    
    public void drawhighlight(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.setPaint(Color.red);
        g.drawPolygon(brick_polygon);

    }
    
    public void disconnect()
    {
        
        if(father_brick != null)
        {
            if((father_brick instanceof LIBrickCall) && (father_i == 0))
                return;
            
            if((father_brick instanceof LIBrickProcedure) && (father_i == 0))
                return;
            
            
            father_brick.child_set_null(father_i);
            father_brick.position_calculer();
            father_brick = null;
        }
    }
    
    
    public int IsFatherMatchAndGetSocket(Brick brick_child_maybe, int x, int y)
    {
        if(brick_child_maybe == this)
            return -1;
        
        for(int i = 0; i<brickchildrensocketrect.size();i++)
        {
            if(child_is_empty(i))
            if(child_getBrickType(i) == brick_child_maybe.getBrickType())
            if(brickchildrensocketrect.get(i).contains(x, y))
            {
                return i;
            }
        }
        return -1;
    }
    
    
    public boolean IsOnTopLevel()
    {
       return (father_brick == null);
       
    }
    
    
    
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        return null;
    }
    
    
    
    public void Width_Adapt(FontMetrics fm)
    {
        int nw = getWidthInterior();
        
        for(int i = 0; i< getNbChildren(); i++)
        {
            nw = Math.max(nw, fm.stringWidth(child_getString(i)) + 12);
        }
        
        setBrick_width_interior(nw);
        position_calculer();
    }
    
    
    
}


