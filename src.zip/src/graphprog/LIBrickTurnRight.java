/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

/**
 *
 * @author proprietaire
 */
public class LIBrickTurnRight extends LIBrickTurn {
     public LIBrickTurnRight()
     {
         super(Math.PI/2);
     }

}
