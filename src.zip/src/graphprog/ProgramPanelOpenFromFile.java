/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import graphprog.LIBrickBinaryOperator.Operator;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author proprietaire
 */
public class ProgramPanelOpenFromFile {
    private ProgramPanel pp = null;
    private Point position_courante;

    ProgramPanelOpenFromFile(ProgramPanel pp)
    {
        this.pp = pp;
    }
    
    public Point getPosition_courante() {
        return position_courante;
    }

    public void setPosition_courante(Point position_courante) {
        this.position_courante = position_courante;
    }

    void briques_lire(StreamTokenizer entree) throws IOException {
        while (entree.ttype != StreamTokenizer.TT_EOF) {
            brique_lire(entree);

        }
    }

    
    void programme_charger(String fichier_nom)
     {
        BufferedReader fichier = null;
        StreamTokenizer entree = null;
        try {


            fichier = new BufferedReader(new FileReader(fichier_nom));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProgramPanelOpenFromFile.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        
        try {
        entree = new StreamTokenizer(fichier);
        entree.wordChars('_', '_');
        entree.wordChars('-', '-');
        entree.wordChars('.', '.');

        entree.nextToken();

        briques_lire(entree);


    }
    catch
     

    
        (IOException ex)
         {
            System.out.println(entree.toString());
            Logger.getLogger(Challenge.class.getName()).log(Level.SEVERE, null, ex);
    }
        
    finally

    {
        try {
            fichier.close();
        } catch (IOException ex) {
            Logger.getLogger(Challenge.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }
    
    
    private Point position_lire(StreamTokenizer entree) throws IOException {
        int x = 0;
        int y = 0;

//        if(!(((char) entree.ttype) == '('))
//            throw new IOException();
//        
//        entree.nextToken();
//        if(!entree.sval.equals("pos"))
//            throw new IOException();

        entree.nextToken();
        x = (int) entree.nval;

        entree.nextToken();
        y = (int) entree.nval;

        entree.nextToken();

        if (!(((char) entree.ttype) == ')')) {
            throw new IOException("there is no ')' at the end of your '(setposition ...)' expression.");
        }


        return new Point(x, y);
    }


    
    
    private LIBrickMoveWithParameter brique_lire_movewp(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        LIBrickMoveWithParameter b = new LIBrickMoveWithParameter();
        b.move(getPosition_courante());
        b.parameter_set(brique_lire(entree));
        b.sequence_nextbrick_set(brique_lire(entree));
        return b;
    }
    
    
    private LIBrickTurnWithParameter brique_lire_turnwp(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        LIBrickTurnWithParameter b = new LIBrickTurnWithParameter();
        b.move(getPosition_courante());
        b.parameter_set(brique_lire(entree));
        b.sequence_nextbrick_set(brique_lire(entree));
        return b;
    }

    private LIBrickInteger brique_lire_integer(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        Point pos = getPosition_courante();
        entree.nextToken();
        LIBrickInteger b = new LIBrickInteger((int) entree.nval);
        b.move(pos);
        return b;
    }

    private LIBrickVariable brique_lire_variable(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        Point pos = getPosition_courante();
        LIBrickVariable b = new LIBrickVariable(Traduction.traduire(entree.sval));
        entree.nextToken();
        b.move(pos);
        return b;
    }

    private LIBrickCall brique_lire_call(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        int nbparameters = (int) entree.nval;
        entree.nextToken();
        Point pos = getPosition_courante();

        BrickWithText procedurename_brick = brique_lire_procedurename(entree);
        
        LIBrickCall b = null;
        LIBrickProcedure procedure_brick =  pp.getBrickProcedure(procedurename_brick.getText());
        
        if(procedure_brick == null)
        {
            b = new LIBrickCall(procedurename_brick,
                                nbparameters);
        }
        else
        {
              b = new LIBrickCall(procedurename_brick,
                pp.getBrickProcedure(procedurename_brick.getText()));
        }
        b.move(pos);

        for (int i = 0; i < nbparameters; i++) {
            b.parameter_set(0, brique_lire(entree));
        }

        b.sequence_nextbrick_set(brique_lire(entree));

        return b;
    }

    private LIBrickProcedure brique_lire_procedure(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        int nbparameters = (int) entree.nval;
        entree.nextToken();
        Point pos = getPosition_courante();

        BrickWithText procedure_name = brique_lire_procedurename(entree);

        BrickWithText[] parameters;
        parameters = new BrickWithText[nbparameters];

        for (int i = 0; i < nbparameters; i++) {
            parameters[i] = brique_lire_variablename(entree);
        }

        LIBrickProcedure b = new LIBrickProcedure(procedure_name, parameters);

        b.Body_Brick_Set(brique_lire(entree));
        b.move(pos);
        return b;
    }

    private Brick brique_lire_binaryoperator(StreamTokenizer entree, Operator op) throws IOException {
        entree.nextToken();
        LIBrickBinaryOperator b = new LIBrickBinaryOperator(op);
        b.move(getPosition_courante());
        b.Operand1_set(brique_lire(entree));
        b.Operand2_set(brique_lire(entree));
        return b;
    }

    private Brick brique_lire_if(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        LIBrickIF b = new LIBrickIF();
        b.move(getPosition_courante());
        b.condition_brick_set(brique_lire(entree));
        b.body_then_brick_set(brique_lire(entree));
        b.sequence_nextbrick_set(brique_lire(entree));
        return b;
    }
    
    private Brick brique_lire_forwp(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        LIBrickForWithVariableRepetition b = new LIBrickForWithVariableRepetition();
        b.move(getPosition_courante());
        b.child_set(0, brique_lire(entree));
        b.child_set(1, brique_lire(entree));
        b.sequence_nextbrick_set(brique_lire(entree));
        return b;
    }

    private Brick brique_lire_ifthenelse(StreamTokenizer entree) throws IOException {
        entree.nextToken();
        LIBrickIfThenElse b = new LIBrickIfThenElse();
        b.move(getPosition_courante());
        b.condition_brick_set(brique_lire(entree));
        b.body_then_brick_set(brique_lire(entree));
        b.body_else_brick_set(brique_lire(entree));
        b.sequence_nextbrick_set(brique_lire(entree));
        return b;
    }

    private BrickWithText brique_lire_procedurename(StreamTokenizer entree) throws IOException {
        BrickWithText b = new BrickWithText(BrickType.PROCEDURENAME, Traduction.traduire(entree.sval));
        pp.Brick_Insert(b);
        entree.nextToken();
        return b;
    }
    
    
    String lire_procedurename(StreamTokenizer entree) throws IOException {
        String procedure_name = entree.sval;
        entree.nextToken();
        return procedure_name;
    }
    
    
    private BrickWithText brique_construire_procedurename(String procedure_name) throws IOException {
        BrickWithText b = new BrickWithText(BrickType.PROCEDURENAME, procedure_name);
        pp.Brick_Insert(b);
        return b;
    }
    

    private BrickWithText brique_lire_variablename(StreamTokenizer entree) throws IOException {
        BrickWithText b = new BrickWithText(BrickType.INTEGER, Traduction.traduire(entree.sval));
        pp.Brick_Insert(b);
        entree.nextToken();
        return b;
    }

    private Brick brique_lire(StreamTokenizer entree) throws IOException {
        Brick b = null;




        if (((char) entree.ttype) == '(') {
            entree.nextToken();

            if (entree.sval.equals("setposition")) {
                setPosition_courante(
                        position_lire(entree));
                entree.nextToken();
                return null;

            } else if (entree.sval.equals("for")) {
                entree.nextToken();

                b = new LIBrickFor((int) entree.nval);
                entree.nextToken();
                b.move(getPosition_courante());
                b.child_set(0, brique_lire(entree));
                b.child_set(1, brique_lire(entree));
            } else if (entree.sval.equals("program")) {
                entree.nextToken();

                b = pp.getBrickMainProcedure();
                b.move(getPosition_courante());
                b.child_set(0, brique_lire(entree));
                if (!(((char) entree.ttype) == ')')) {//s'il n'y a pas de ) à la fin
                    throw new IOException(entree.toString() + ", ) missing");
                } else {
                    entree.nextToken();
                }
                return b;
            }
            else if (entree.sval.equals("move")) {
                entree.nextToken();
                b = new LIBrickMove((int) entree.nval);
                entree.nextToken();
                b.move(getPosition_courante());
                b.child_set(0, brique_lire(entree));
            } else if (entree.sval.equals("movewp")) {
                b = brique_lire_movewp(entree);
            } else if (entree.sval.equals("turnwp")) {
                b = brique_lire_turnwp(entree);

            } else if (entree.sval.equals("int")) {
                b = brique_lire_integer(entree);
            } else if (entree.sval.equals("var")) {
                b = brique_lire_variable(entree);
            } else if (entree.sval.equals("call")) {
                b = brique_lire_call(entree);
            } else if (entree.sval.equals("proc")) {
                b = brique_lire_procedure(entree);
            } else if (entree.sval.equals("turn")) {
                entree.nextToken();
                b = new LIBrickTurn(entree.nval * Math.PI / 180);
                entree.nextToken();
                b.move(getPosition_courante());
                b.child_set(0, brique_lire(entree));
            } else if (entree.sval.equals("if")) {
                b = brique_lire_if(entree);
            } else if (entree.sval.equals("forwp")) {
                b = brique_lire_forwp(entree);
            } else if (entree.sval.equals("ifthenelse")) {
                b = brique_lire_ifthenelse(entree);
            } else if (entree.sval.equals("minus")) {
                b = brique_lire_binaryoperator(entree, LIBrickBinaryOperator.Operator.opMinus);
            } else if (entree.sval.equals("egalitytest")) {
                b = brique_lire_binaryoperator(entree, LIBrickBinaryOperator.Operator.opEgalityTest);
            } else if (entree.sval.equals("superiortest")) {
                b = brique_lire_binaryoperator(entree, LIBrickBinaryOperator.Operator.opSuperiorTest);
            } else if (entree.sval.equals("differenttest")) {
                b = brique_lire_binaryoperator(entree, LIBrickBinaryOperator.Operator.opDifferentTest);
            } else if (entree.sval.equals("times") | entree.sval.equals("mul")) {
                b = brique_lire_binaryoperator(entree, LIBrickBinaryOperator.Operator.opTimes);
            } else if (entree.sval.equals("div")) {
                b = brique_lire_binaryoperator(entree, LIBrickBinaryOperator.Operator.opDivide);
            }

            if (!(((char) entree.ttype) == ')')) {//s'il n'y a pas de ) à la fin
                throw new IOException(entree.toString() + ", ) missing");
            } else {
                entree.nextToken();
            }
        } else if (entree.sval == null) {
            throw new IOException(entree.toString() + "no (, no nobrick, no string...");
        } else if (entree.sval.equals("nobrick")) {
            entree.nextToken();
            return null;
        } else {
            throw new IOException(entree.toString() + "no (, no nobrick...");
        }


        pp.Brick_Insert(b);
        return b;


    }
}
