/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Graphics;
import java.io.BufferedWriter;
import java.io.IOException;
import javax.swing.ImageIcon;

/**
 *
 * @author proprietaire
 */
public class LIBrickMoveWithParameter extends BrickWithSequence {
 
    private ImageIcon imgTurtle;
    
    public LIBrickMoveWithParameter()
    {
        super(2);
        child_setBrickType(0, BrickType.INTEGER);
        
        imgTurtle = Images.get( java.util.ResourceBundle.getBundle("resources/LIBricks").getString("/graphprog/resources/brick_turtle.png") );
        setColor(Color.getHSBColor(0.3f, 0.5f, 1.0f));
        setBrick_width(100);
                
    }
    
    
    public void parameter_set(Brick b)
    {
        child_set(0, b);
    }
    
    public Brick parameter_get()
    {
        return child_get(0);
    }
    
    
    @Override
    public void draw(Graphics g)
    {
        super.draw(g);
        
        g.drawImage(imgTurtle.getImage(),
                    getPosx() + 5, getPosy() + 2, null);
        g.setColor(Color.BLACK);
        g.drawString(java.util.ResourceBundle.getBundle("resources/LIBricks").getString("move"), getPosx() + 48, getPosy() + 20);
    }
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        if(parameter_get() == null)
        {
            mt.execution_error(this, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("The_brick_Move_has_no_parameter."));
            return null;
        }
        
        parameter_get().execute_and_return_future(mt);
        mt.turtle_move(mt.ValuePop());
        return BrickWithSequence_BrickFutureGet(mt);
    }
    
    
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(movewp ");  
        brick_sauvegarder_tenter(parameter_get(), writer);
        brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
        writer.write(")");
    }
    
    
    
}
