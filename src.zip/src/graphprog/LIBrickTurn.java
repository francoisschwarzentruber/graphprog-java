/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.BufferedWriter;
import java.io.IOException;
import javax.swing.ImageIcon;

/**
 *
 * @author proprietaire
 */
public class LIBrickTurn extends BrickWithSequence {
    
    private double turn_angle_in_radian;
    
    private String text = java.util.ResourceBundle.getBundle("resources/LIBricks").getString("turn_90°_to_the_right!");
    private ImageIcon imgTurtle;
    
    
    
    
    public LIBrickTurn(double turn_angle_in_radian)
    {
        super(1);
        
        this.turn_angle_in_radian = turn_angle_in_radian;
        this.turn_angle_in_radian = getAngleInDegrees() * Math.PI / 180;
        
        
        imgTurtle = Images.get(java.util.ResourceBundle.getBundle("resources/LIBricks").getString("/graphprog/resources/brick_turtle.png"));  
                
        
        
        text = java.util.ResourceBundle.getBundle("resources/LIBricks").getString("turns_")
               // + String.valueOf(Math.round(turn_angle_in_radian * 180 / Math.PI) 
                 // + java.util.ResourceBundle.getBundle("resources/LIBricks").getString("°_!"));
       ;
        
        setColor(Color.getHSBColor(0.3f, 0.5f, 1.0f));
        setBrick_width(120);
                
    }
    
    
    private int getAngleInDegrees()
    {
        return (int) Math.round(turn_angle_in_radian * 180 / Math.PI);
    }
    
    
    private void turtle_turn_draw(Graphics g, int turtle_with_angle_x, double angle)
    {
        Graphics2D g2 = (Graphics2D) g;
        int turtle_with_angle_y = getPosy() + getHeight() / 2;
        AffineTransform xform;
        
        xform = new AffineTransform();
        xform.setToIdentity();
        xform.setToTranslation(turtle_with_angle_x,
                               turtle_with_angle_y);
                                // - Math.round(imgTurtle.getIconHeight() / 2
                                  //             * Math.sin(turn_angle_in_radian)));
        xform.rotate(angle);
        xform.translate(-imgTurtle.getIconWidth() / 2, -imgTurtle.getIconHeight() / 2);
        
        g2.drawImage(imgTurtle.getImage(), xform, null);
    }
    
    @Override
    public void draw(Graphics g)
    {
        super.draw(g);
        
        g.setColor(Color.BLACK);
        g.drawString(text, getPosx() + 48, getPosy() + 20);
        
        turtle_turn_draw(g, getPosx() + 20, 0);
        turtle_turn_draw(g, getPosx() + getWidthInterior() - 5, turn_angle_in_radian);
        
        
    }
    
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        mt.turtle_turn(turn_angle_in_radian);
        return BrickWithSequence_BrickFutureGet(mt);
    }   
    
    
    
        
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(turn ");  
        writer.write(String.valueOf(getAngleInDegrees()));
        writer.write(" "); 
        brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
        writer.write(")");
    }
    
    
}
