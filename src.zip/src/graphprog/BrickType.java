/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Polygon;

/**
 *
 * @author proprietaire
 */

enum BrickShape {
    NOTHING, BOUTTRONQUE, POINTINTERROGATION, TRIANGLE;
}

public enum BrickType {
    PROGRAM(BrickShape.BOUTTRONQUE),
    PROCEDURE(BrickShape.BOUTTRONQUE),
    PROCEDURENAME(BrickShape.NOTHING),
    INSTRUCTION(BrickShape.NOTHING),
    BOOLEAN(BrickShape.POINTINTERROGATION),
    INTEGER(BrickShape.TRIANGLE);
    
    private BrickShape bs;
    
    BrickType(BrickShape bs)
    {
         this.bs = bs;
    }
    
    
    private Polygon ShapeFragment(int x, int y, int height)
    {
        Polygon p = new Polygon();
        final int coin = 4;
        final int triangle_width = 6;
        switch(bs)
        {
            case BOUTTRONQUE:
                
                p.addPoint(x+coin, y);
                p.addPoint(x, y+coin);
                p.addPoint(x, y+height-coin);
                p.addPoint(x+coin, y+height);
                break;
                
            case TRIANGLE:
                p.addPoint(x+triangle_width, y);
                p.addPoint(x, y+height / 2);
                p.addPoint(x+triangle_width, y+height);
                break;
                
            case POINTINTERROGATION:
                p.addPoint(x, y);
                
                for(int i = 0; i<=10; i++)
                {
                    double angle = Math.PI * i / 10;
                    p.addPoint(x + (int) Math.round(6*Math.sin(angle)),
                          y + height / 3 - (int) Math.round((height / 5) * Math.cos(angle)));
                    
                }
                
                for(int i = 0; i<=10; i++)
                {
                    double angle = Math.PI * i / 10;
                    p.addPoint(x + (int) Math.round(3*Math.sin(angle)),
                          y + 3*height / 4 - (int) Math.round((height / 15) * Math.cos(angle)));
                    
                }
                
                p.addPoint(x, y+height);
                
                break;
                
            default: 
                p.addPoint(x, y);
                p.addPoint(x, y+height);
        }
        
        return p;
    }
    
    
    
    public void ShapeTopToBottom(Polygon p, int x, int y, int height)
    {
        Polygon fragment = ShapeFragment(x, y, height);
        
        for(int i = 0; i < fragment.npoints; i++)
        {
            p.addPoint(fragment.xpoints[i], fragment.ypoints[i]);
        }
        
    }
    
    
    public void ShapeBottomToTop(Polygon p, int x, int y, int height)
    {
        Polygon fragment = ShapeFragment(x, y, height);
        
        for(int i = fragment.npoints - 1 ; i >= 0; i--)
        {
            p.addPoint(fragment.xpoints[i], fragment.ypoints[i]);
        }
        
    }
    
    
}
