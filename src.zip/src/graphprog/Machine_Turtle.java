/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.util.Stack;


/**
 *
 * @author proprietaire
 */
public class Machine_Turtle extends Machine_Turtle_Primitive {
    
    private GraphprogView graphprogview = null;
    private ProgramPanel pp = null;
    private Stack<Machine_Turtle_Information> call_stack = null;
    private Stack<Integer> value_stack = null;
    private Brick bricktoexecute = null;
    private boolean finished = false;
    private Machine_Turtle_View mtv = null;


    public Brick CallStack_PopPopAndGiveFuture()
    {
        Brick b = null;
        while((b == null) && (!CallStack_IsEmpty()))
            b = CallStack_Pop().getBrick_return();
        return b;
    }
    
    public void CallStack_Push(Machine_Turtle_Information mti)
    {
        call_stack.push(mti);
    }
    
    public Machine_Turtle_Information CallStack_Pop()
    {
        return call_stack.pop();
    }
    
    public Machine_Turtle_Information CallStack_Peek()
    {
        return call_stack.peek();
    }
    
    public boolean CallStack_IsEmpty()
    {
        return call_stack.isEmpty();
    }
    
    
    public void execution_error(Brick b, String s)
    {
        pp.setBrickHighLighted(b);
        graphprogview.execution_error(s);
        finish();
    }
    
    
    
    public Machine_Turtle(TurtleEnvironment turtle_environment, ProgramPanel pp, Machine_Turtle_View mtv, GraphprogView graphprogview,
                          Machine_Turtle_Primitive.Machine_Turtle_Speed speed )
    {
        super(turtle_environment);
        call_stack = new Stack<Machine_Turtle_Information>();
        value_stack = new Stack<Integer>();
        this.pp = pp;
        this.mtv = mtv;
        this.graphprogview = graphprogview;
        setSpeed(speed);
    }
   
    
    
    public void setBrickToExecute(Brick b)
    {
        bricktoexecute = b;
        
    }
    
    
    public void ValuePush(int i)
    {
        value_stack.push(i);
    }
    
    public int ValuePop()
    {
        return value_stack.pop();
    }
    
    public int ValuePeek()
    {
        return value_stack.peek();
    }
    
    public int variable_getvalue(String variable_name)
    {
        for(int i = call_stack.size() - 1; i >= 0; i--) 
        {
            if(call_stack.get(i).variable_isdefined(variable_name))
                return call_stack.get(i).variable_getvalue(variable_name);
        }
        
        execution_error(null, variable_name + " unknown");
        return 0;
    }
    
    
    
    public void execute()
    {
        //la brique exécutée c'est setBrickToExecute
        mtv.Inform_Execute();
        turtle_init();
        
        finished = false;
        while((this.bricktoexecute != null) && !finished)
        {
            this.pp.InfoSupplementaire_Reset();
            this.pp.setBrickHighLighted(this.bricktoexecute);
            this.pp.InfoSupplementaire_Ajouter(this.bricktoexecute,
                           this.bricktoexecute.execute_informations_supplementaires_get(this)
                           );
            
            if(this.bricktoexecute instanceof LIBrickProcedure)
                  informations_supplementaire_procedure((LIBrickProcedure) this.bricktoexecute);
            
            
            this.pp.repaint();
            
            dormir();
            this.bricktoexecute = this.bricktoexecute.execute_and_return_future(this);
            dormir();
        }
        
        pp.noBrickHighLighted();
        pp.InfoSupplementaire_Reset();
        pp.repaint();
        
        Challenge_Test();
        
    }
    
    
    
    public void finish()
    {
         finished = true;
    }
    
    @Override
    public void run()
    {
        execute();
    }
    
    public LIBrickProcedure getBrickProcedure(String name)
    {
        return pp.getBrickProcedure(name);
    }
    
    
    public void Challenge_Test()
    {
        if(!isChallenge())
        {
            mtv.Inform_Stop();
            return;
        }
            
        
        if(Challenge_succeed())
            {
                graphprogview.Challenge_Succeed_Show();
            }
        else
            {
                graphprogview.Challenge_Failed_Show();
            }
    }

    void informations_supplementaire_valeur(Brick brick) {
        this.pp.InfoSupplementaire_Reset();
        if(brick.getBrickType() == BrickType.BOOLEAN)
        {
            if(ValuePeek() != 0)
                this.pp.InfoSupplementaire_Ajouter(brick, "VRAI");
            else
                this.pp.InfoSupplementaire_Ajouter(brick, "FAUX");
                       
        }
        else
        {
            this.pp.InfoSupplementaire_Ajouter(brick,
                                    String.valueOf(ValuePeek()));
        }
        this.pp.setBrickHighLighted(brick);
        this.pp.repaint();
        dormir();
    }
    
    
    
    void informations_supplementaire_procedure(LIBrickProcedure brick) {
        this.pp.InfoSupplementaire_Reset();
        for(int i = 0; i < brick.getNbParameters(); i++)
        {
            this.pp.InfoSupplementaire_Ajouter(
                    brick.parameter_brick_get(i),
                    String.valueOf( variable_getvalue(brick.parameter_name_get(i)) )
                    );
            
            
        }
    }

    
}
