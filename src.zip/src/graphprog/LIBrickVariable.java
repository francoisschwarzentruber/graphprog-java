/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickVariable extends BrickWithText {
 public LIBrickVariable(String variable_name)
 {
     super(BrickType.INTEGER, variable_name);
 }
 
 
 public String variable_name_get()
 {
     return getText();
 }
 
 
     @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        mt.ValuePush(mt.variable_getvalue(variable_name_get()));
        mt.informations_supplementaire_valeur(this);
        return null;
    }
     
     
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(var "); 
        writer.write("\"" + variable_name_get() + "\"");
        writer.write(")");
    } 
     
     
}
