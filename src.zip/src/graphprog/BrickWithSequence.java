/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.ArrayList;


/**
 *
 * @author proprietaire
 */
public class BrickWithSequence extends Brick {
    
    final int Brick_Encoche_Sequence_x = Brick_Encoche_Socket;
    final int Brick_Encoche_Sequence_h = 2;
    final int Brick_Encoche_Sequence_w = 8;
    
    
    public BrickWithSequence(int children_count)
    {
        super(BrickType.INSTRUCTION, children_count);
        child_setBrickType(children_count-1, BrickType.INSTRUCTION);
        
    }
    
    
    
    
    @Override
    public void position_calculer()
    {
        int y = getPosy();
        int i = 0;
        
        brickchildrensocketrect = new ArrayList<Rectangle>();
        brick_polygon = new Polygon();
       // brick_polygon.addPoint(getPosx(), getPosy());
        
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x, y);
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x,
                               y - Brick_Encoche_Sequence_h);
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x + Brick_Encoche_Sequence_w,
                               y - Brick_Encoche_Sequence_h);
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x + Brick_Encoche_Sequence_w,
                               y);
        brick_polygon.addPoint(getPosx() + Brick_width, y);
        
        if(brickchildren.size()==1)
        {
            y += Brick_height_oneline;
        }
        else
        {
            y += Brick_height_littlespace;
        }
        brick_polygon.addPoint(getPosx() + Brick_width, y);
        
        for(i = 0; i<brickchildren.size()-1; i++)
           {
                
                child_setStringPos(i, new Point(getPosx() + 5,
                                      y + 15));
                
                if(!child_is_empty(i))
                {
                    child_get(i).move(getPosx() + Brick_width_interior, y);
                }
                
                brickchildrensocketrect.add(new Rectangle(getPosx() + Brick_width_interior + Socket_X,
                                                          y + Socket_Y,
                                                          Socket_Width, child_height(i) + Socket_HeightMore));
                child_getBrickType(i).ShapeTopToBottom(brick_polygon,
                                                       getPosx() + Brick_width_interior,
                                                       y,
                                                       child_height(i));
                y += child_height(i);
                brick_polygon.addPoint(getPosx() + Brick_width, y);
                y += Brick_height_littlespace;
                brick_polygon.addPoint(getPosx() + Brick_width, y);
           }
        
        
        
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x + Brick_Encoche_Sequence_w,
                               y);
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x + Brick_Encoche_Sequence_w,
                               y - Brick_Encoche_Sequence_h);
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x,
                               y - Brick_Encoche_Sequence_h);
        brick_polygon.addPoint(getPosx() + Brick_Encoche_Sequence_x, y);
        
        height = y - getPosy();
        getBrickType().ShapeBottomToTop(brick_polygon,
                                        getPosx(),
                                        getPosy(),
                                        height);
  
        
        
        
        
        
        brickchildrensocketrect.add(new Rectangle(getPosx() + Socket_X,
                                                  y-Socket_Height_For_SequenceOfAction / 2,
                                                  Brick_width_interior, Socket_Height_For_SequenceOfAction));
        
        i = brickchildren.size()-1;
        if(!child_is_empty(i))
        {
            child_get(i).move(getPosx(), y);
            totalheight = height + child_get(i).getTotalHeight();
        }
        else
            totalheight = height;
        
        //brick_polygon.addPoint(getPosx(), getPosy());
        
        
        
    }
    
    @Override
    public void draw(Graphics g)
    {
        g.setColor(color);
        g.fillPolygon(brick_polygon);
        
        g.setColor(getColorInterior());
        g.fillRect(getPosx()+3, getPosy()+3, getWidthInterior()-6, getHeight()-6);
        
        g.setColor(Color.GRAY);
        g.drawPolygon(brick_polygon);
        
        g.setColor(Color.BLACK);
        for(int i = 0; i<brickchildren.size() -1; i++)
        {
            Point pos = child_getStringPos(i);
            g.drawString(child_getString(i), pos.x, pos.y);
        }
    }

    
    public void sequence_lastbrick_set(Brick b)
    {
        if(sequence_nextbrick_is_empty())
        {
             sequence_nextbrick_set(b);
        }
        else if(!(sequence_nextbrick_get() instanceof BrickWithSequence))
        {
            sequence_nextbrick_set(b);
        }
        else
        {
            ((BrickWithSequence) sequence_nextbrick_get()).sequence_lastbrick_set(b);
        }
    }
    
    
    public void sequence_nextbrick_set(Brick b)
    {
        if(b == sequence_nextbrick_get())
             return;
        
        if(sequence_nextbrick_is_empty() || !(b instanceof BrickWithSequence))
        {
              child_set(brickchildren.size()-1, b);
        }
        else
        {
            Brick bricktoutalafin = sequence_nextbrick_get();
            child_set(brickchildren.size()-1, b);
            ((BrickWithSequence) b).sequence_lastbrick_set(bricktoutalafin);

            
        }
        
    }
    
    public Brick sequence_nextbrick_get()
    {
        return child_get(brickchildren.size()-1);
        
    }
    

    public boolean sequence_nextbrick_is_empty()
    {
        return child_is_empty(brickchildren.size()-1);
        
    }    
    
    protected Brick BrickWithSequence_BrickFutureGet(Machine_Turtle mt)
    {
        if(sequence_nextbrick_is_empty())
        {
            if(mt.CallStack_IsEmpty())
            {
                return null;
            }
            else
            {
                return mt.CallStack_PopPopAndGiveFuture();
                
                
            }
            
            
        }
        else
        {
            return child_get(brickchildren.size()-1);
        }
    }
    
    
    @Override
    public int IsFatherMatchAndGetSocket(Brick brick_child_maybe, int x, int y)
    {
        int result = super.IsFatherMatchAndGetSocket(brick_child_maybe, x, y);
        
        if(result >= 0)
            return result;
        
        if(brick_child_maybe == this)
            return -1;
        if(brick_child_maybe == sequence_nextbrick_get())
            return -1;
        
        int i = brickchildrensocketrect.size() - 1;

        if(child_getBrickType(i) == brick_child_maybe.getBrickType())
        if(brickchildrensocketrect.get(i).contains(x, y))
        {
            return i;
        }
        return -1;
    }
    
}
