/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickMainProcedure extends BrickWithoutSequence {
    public LIBrickMainProcedure()
    {
        super(BrickType.PROGRAM, 1);
        
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("program"));
        
        setColor(Color.getHSBColor(0.0f, 0.5f, 0.8f));
        

    }
    
    
    public Brick Body_Brick_Get()
    {
        return child_get(0);
    }
    
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        return Body_Brick_Get();
    }
    
    
    
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(program ");   
        brick_sauvegarder_tenter(Body_Brick_Get(), writer);
        writer.write(")");
    }
    
    
}
