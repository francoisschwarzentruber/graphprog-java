/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Graphics;
import java.io.BufferedWriter;
import java.io.IOException;
import javax.swing.ImageIcon;

/**
 *
 * @author proprietaire
 */
public class LIBrickMove extends BrickWithSequence {
    private int MoveLength = 0;
    
    
    private String text = java.util.ResourceBundle.getBundle("resources/LIBricks").getString("move_2mm!");
    private ImageIcon imgTurtle;
    
    public LIBrickMove(int MoveLength)
    {
        super(1);
       
        imgTurtle = Images.get( java.util.ResourceBundle.getBundle("resources/LIBricks").getString("/graphprog/resources/brick_turtle.png") );
        this.MoveLength = MoveLength;
        text = java.util.ResourceBundle.getBundle("resources/LIBricks").getString("moves_") + String.valueOf(this.MoveLength) + java.util.ResourceBundle.getBundle("resources/LIBricks").getString("_mm!");
        setColor(Color.getHSBColor(0.3f, 0.5f, 1.0f));
        setBrick_width(Math.max(getPosx() + 10 + imgTurtle.getIconWidth() + MoveLength + 10,
                           150));
                
    }
    
    @Override
    public void draw(Graphics g)
    {
        super.draw(g);
        
        int turtle_decal_y = 3;
        g.drawImage(imgTurtle.getImage(),
                    getPosx() + 10, getPosy() + getHeight() / 2 - imgTurtle.getIconHeight() / 2 - turtle_decal_y, null);
        g.setColor(Color.BLACK);
        g.drawString(text, getPosx() + 48, getPosy() + 4  + getHeight() / 2 + imgTurtle.getIconHeight() / 2 - turtle_decal_y);
        
        int x = getPosx() + 10 + imgTurtle.getIconWidth();
        int y = getPosy() + getHeight() / 2 - turtle_decal_y - 2;
        
        g.drawLine(x, y, x + MoveLength, y);
        
        if(MoveLength > 10)
        {
            x = x + MoveLength;

            int fleche_longueur = 6;
            double fleche_angle = 0.3;

            g.drawLine(x, y, x - (int) Math.round(fleche_longueur * Math.cos(fleche_angle)),
                             y - (int) Math.round(fleche_longueur * Math.sin(fleche_angle)));

            g.drawLine(x, y, x - (int) Math.round(fleche_longueur * Math.cos(fleche_angle)),
                             y + (int) Math.round(fleche_longueur * Math.sin(fleche_angle)));
        }
    }
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        mt.turtle_move(MoveLength);
        return BrickWithSequence_BrickFutureGet(mt);
    }
    
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(move ");  
        writer.write(String.valueOf(MoveLength));
        writer.write(" "); 
        brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
        writer.write(")");
    }
}
