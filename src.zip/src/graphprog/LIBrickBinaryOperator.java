/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */



public class LIBrickBinaryOperator extends BrickWithoutSequence {
    public enum Operator
        {opMinus(BrickType.INTEGER, BrickType.INTEGER, BrickType.INTEGER),
         opEgalityTest(BrickType.BOOLEAN, BrickType.INTEGER, BrickType.INTEGER),
         opPlus(BrickType.INTEGER, BrickType.INTEGER, BrickType.INTEGER),
         opTimes(BrickType.INTEGER, BrickType.INTEGER, BrickType.INTEGER),
         opDivide(BrickType.INTEGER, BrickType.INTEGER, BrickType.INTEGER),
         opDifferentTest(BrickType.BOOLEAN, BrickType.INTEGER, BrickType.INTEGER),
         opSuperiorTest(BrickType.BOOLEAN, BrickType.INTEGER, BrickType.INTEGER);
    
         private BrickType typeresult;

        public BrickType getTypearg1() {
            return typearg1;
        }

        public BrickType getTypearg2() {
            return typearg2;
        }

        public BrickType getTyperesult() {
            return typeresult;
        }
        
        
         private BrickType typearg1;
         private BrickType typearg2;
         
        Operator(BrickType typeresult, BrickType typearg1, BrickType typearg2)
        {
            this.typeresult = typeresult;
            this.typearg1 = typearg1;
            this.typearg2 = typearg2;
            
        }
    };
    
    private Operator op;
    
    
    
    public LIBrickBinaryOperator(Operator op)
    {
        
        super(op.getTyperesult(), 2);
        this.op = op;
        
        child_setBrickType(0, op.getTypearg1());
        child_setBrickType(1, op.getTypearg2());
        setColor(Color.WHITE);
        setBrick_width(48);
    }
    
    
    public void Operand1_set(Brick b)
    {
        child_set(0, b);
    }
    
    public Brick Operand1_get()
    {
        return child_get(0);
    }
    
    
    public void Operand2_set(Brick b)
    {
        child_set(1, b);
    }
    
    
    public Brick Operand2_get()
    {
        return child_get(1);
    }
    
    
    private int operator_compute(Operator op, int v1, int v2)
    {
        switch (op)
        {
            case opEgalityTest:
                if(v1 == v2)
                    return 1;//VRAI
                else
                    return 0;//FAUX

                
            case opMinus:
                return v1 - v2;
                
            case opPlus:
                return v1 + v2;
                
            case opTimes:
                return v1 * v2;
            
            case opDivide:
                return v1 / v2;
                
            case opDifferentTest:
                if(v1 == v2)
                    return 0;//FAUX
                else
                    return 1;//VRAI
                
            case opSuperiorTest:
                if(v1 > v2)
                    return 1;//FAUX
                else
                    return 0;//VRAI
                
            default: return 0;
        }    
    }
    
    
     @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        if(Operand2_get() == null)
            mt.ValuePush(0);
        else         
            Operand2_get().execute_and_return_future(mt);
        
        if(Operand1_get() == null)
            mt.ValuePush(0);
        else  
            Operand1_get().execute_and_return_future(mt);
        
        int v1 = mt.ValuePop();
        int v2 = mt.ValuePop();

        mt.ValuePush(operator_compute(op, v1, v2));
        
        mt.informations_supplementaire_valeur(this);
        return null;
    }
     
    private String operator_text_in_savedfiles_get() 
    {
        switch (op)
        {
            case opEgalityTest:
                return "egalitytest";

            case opMinus:
                return "minus";
                
            case opPlus:
                return "plus";
                
            case opTimes:
                return "times";
            
            case opDivide:
                return "div";
                
            case opDifferentTest:
                return "differenttest";
            
            case opSuperiorTest:
                return "superiortest";
                
            default: return "??";
        }   
        
    }
    
    
    
    
    private String operator_text_get()
    {
        switch (op)
        {
            case opEgalityTest:
                return java.util.ResourceBundle.getBundle("resources/LIBricks").getString("=");

                
            case opMinus:
                return java.util.ResourceBundle.getBundle("resources/LIBricks").getString("-");
                
            case opPlus:
                return java.util.ResourceBundle.getBundle("resources/LIBricks").getString("+");
                
            case opTimes:
                return java.util.ResourceBundle.getBundle("resources/LIBricks").getString("×");
            
            case opDivide:
                return "÷";
                
            case opDifferentTest:
                return java.util.ResourceBundle.getBundle("resources/LIBricks").getString("≠");
            
            case opSuperiorTest:
                return ">";
                
            default: return java.util.ResourceBundle.getBundle("resources/LIBricks").getString("??");
        }    
    }
     
    @Override
    public void draw(Graphics g)
    {
        g.setColor(color);
        g.fillPolygon(brick_polygon);
        g.setColor(Color.BLACK);
        g.drawPolygon(brick_polygon);
        
        g.setColor(Color.BLACK);
        Font f = g.getFont();
        g.setFont(f.deriveFont(32f));
        g.drawString(operator_text_get(), getPosx() + 5,getPosy() + 40);
        g.setFont(f);
    }
    
    
    
    
    
     @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(");   
        writer.write(operator_text_in_savedfiles_get());
        writer.write(" ");
        brick_sauvegarder_tenter(Operand1_get(), writer);
        brick_sauvegarder_tenter(Operand2_get(), writer);
        writer.write(")");
    }       
    
    
    
}
