/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package graphprog;


import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

/**
 *
 * @author proprietaire
 */
public class Challenge {

    private ImageIcon imgWhatTheTurtleHasToDraw = null;
    private int imgWhatTheTurtleHasToDraw_OriginX = 0;
    private int imgWhatTheTurtleHasToDraw_OriginY = 0;
    private String mission_text = "";
    
    private ProgramPanelOpenFromFile ppof = null;

    private void infoimage_lire(StreamTokenizer entree) throws IOException {
        if (!(((char) entree.ttype) == '(')) {
            throw new IOException();
        }

        entree.nextToken();

        entree.nextToken();

        imgWhatTheTurtleHasToDraw = Images.get("/graphprog/resources/challenges/" + entree.sval);

        entree.nextToken();

        if (!(((char) entree.ttype) == ')')) {
            throw new IOException();
        }

        entree.nextToken();
        if (!(((char) entree.ttype) == '(')) {
            throw new IOException();
        }

        entree.nextToken();

        entree.nextToken();

        imgWhatTheTurtleHasToDraw_OriginX = (int) entree.nval;
        entree.nextToken();

        imgWhatTheTurtleHasToDraw_OriginY = (int) entree.nval;

        entree.nextToken();
        if (!(((char) entree.ttype) == ')')) {
            throw new IOException();
        }

        entree.nextToken();

        if (!(((char) entree.ttype) == '(')) {
            throw new IOException();
        }

        entree.nextToken();

        entree.nextToken();

        mission_text = Traduction.traduire(entree.sval);

        entree.nextToken();

        if (!(((char) entree.ttype) == ')')) {
            throw new IOException(entree.toString());
        } else {
            entree.nextToken();
        }
    }

    

    
    public void fichier_charger(String fichier_nom) {
        BufferedReader fichier = null;
        StreamTokenizer entree = null;


            fichier = new BufferedReader(
                    new InputStreamReader(getClass().getResourceAsStream(fichier_nom)));

        
        
        try {
        entree = new StreamTokenizer(fichier);
        entree.wordChars('_', '_');
        entree.wordChars('-', '-');
        entree.wordChars('.', '.');

        entree.nextToken();
        infoimage_lire(entree);

        ppof.briques_lire(entree);




    }
    catch
     

    
        (IOException ex)
         {
            System.out.println(entree.toString());
            Logger.getLogger(Challenge.class.getName()).log(Level.SEVERE, null, ex);
    }
        
    finally

    {
        try {
            fichier.close();
        } catch (IOException ex) {
            Logger.getLogger(Challenge.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }

public Challenge(ProgramPanel pp, String challenge_name) {
        ppof = new ProgramPanelOpenFromFile(pp);
        pp.Brick_ResetAll();
        
        fichier_charger("/graphprog/resources/" + challenge_name + ".logo-scheme");
       
    }

public ImageIcon WhatTheTurtleHasToDraw_getImageIcon()
    {
        return imgWhatTheTurtleHasToDraw;
    }

public Point WhatTheTurtleHasToDraw_getImageIconOriginInImage()
    {
        return new Point(imgWhatTheTurtleHasToDraw_OriginX,
                         imgWhatTheTurtleHasToDraw_OriginY);   
    }

public String mission_text_get()
    {
        return mission_text;
    
    }
}
