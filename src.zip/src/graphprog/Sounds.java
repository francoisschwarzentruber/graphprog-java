/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.applet.AudioClip;
import java.applet.Applet;
import java.net.URL;

/**
 *
 * @author proprietaire
 */
public class Sounds {
    
    static public URL getURL(String ressourcename)
    {
        Sounds snd; // ça sert à rien mais java ça pue
        snd = new Sounds();
        
        return snd.getClass().getResource(ressourcename);
        
    }
    
    static public AudioClip get(URL url)
    {
        return Applet.newAudioClip(url);
    }
    
    
    static public AudioClip get(String ressourcename)
    {
        return Applet.newAudioClip(getURL(ressourcename));
    }
}
