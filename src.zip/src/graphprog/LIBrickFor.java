/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickFor extends BrickWithSequence {
    private int for_count = 0;
    
    public LIBrickFor(int for_count)
    {
        
        super(2);
        
        child_setBrickType(0, BrickType.INSTRUCTION);
        
        this.for_count = for_count;
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("repeat_") + String.valueOf(for_count) + java.util.ResourceBundle.getBundle("resources/LIBricks").getString("×"));
        setBrick_width(120);
        setColor(Color.getHSBColor(0.15f, 0.5f, 1.0f));
    }
    
    
    public int LIBrickFor_For_Count_Get()
    {
        return for_count;
    }
    
    
    public Brick Body_Brick_Get()
    {
        return child_get(0);
    }
    
    
    
    private int dire_combien_de_fois_encore(Machine_Turtle mt)
    {
        if(mt.CallStack_IsEmpty())
            return for_count;
        else
        {
            Machine_Turtle_Information mti = mt.CallStack_Peek();
            if(mti.getBrick_return() == this)
                return mti.getForCount();
            else
                return for_count;
                       
        }
            
    }
    
    
    
    private int dire_la_combientieme_fois_on_est(Machine_Turtle mt)
    {
        return for_count - dire_combien_de_fois_encore(mt) + 1;
    }
    
    
    
    private boolean dire_si_ya_encore_a_executer_de_la_boucle(Machine_Turtle mt)
    {
        return (dire_combien_de_fois_encore(mt) != 0);
    }
    
    
    @Override
    String execute_informations_supplementaires_get(Machine_Turtle aThis) {
        if(dire_si_ya_encore_a_executer_de_la_boucle(aThis))
        {
            if(dire_la_combientieme_fois_on_est(aThis) == 1)
            {
                return "1ère fois";
            }
            else
                  return dire_la_combientieme_fois_on_est(aThis) + "e fois";
        }
        else
        {
            return "fini !";
        }
        
    }
    
    
    

    
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        if(Body_Brick_Get() == null)
        {
            return BrickWithSequence_BrickFutureGet(mt);
            
        }
        
        
        Machine_Turtle_Information mti;
        
        if(mt.CallStack_IsEmpty())
        {
            mti = new Machine_Turtle_Information(this);
            mti.setForCountAtTheBeginning(for_count);
            mt.CallStack_Push(mti);
            
            mti.decForCount();
            mti = new Machine_Turtle_Information(this);
            mt.CallStack_Push(mti);
            
            return Body_Brick_Get();
        
        }
        else
        {
            mti = mt.CallStack_Peek();
            if(mti.getBrick_return() == this)
             {    
                 if(mti.getForCount() <= 0)
                 {
                    mt.CallStack_Pop(); 
                    return BrickWithSequence_BrickFutureGet(mt);  
                 }
                 else
                 {
                     mti.decForCount();
                     mti = new Machine_Turtle_Information(this);
                     mt.CallStack_Push(mti);
                     return Body_Brick_Get();
                 }
             }
            else
            {
                mti = new Machine_Turtle_Information(this);
                mti.setForCountAtTheBeginning(for_count);
                mt.CallStack_Push(mti);
                
                mti.decForCount();
                mti = new Machine_Turtle_Information(this);
                mt.CallStack_Push(mti);
            
                return Body_Brick_Get();
            }
            }
        }
        
    
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(for ");
        writer.write(String.valueOf(LIBrickFor_For_Count_Get()));
        writer.write(" ");
        brick_sauvegarder_tenter(Body_Brick_Get(), writer);
        brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
        writer.write(")");
    }
        
}



