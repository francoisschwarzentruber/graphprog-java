/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickProcedure extends BrickWithoutSequence {
    public LIBrickProcedure(BrickWithText brick_procedure_name, BrickWithText ... parameters)
    {
        
        super(BrickType.PROCEDURE, 2 + parameters.length);
        
        for(int i = 0; i < getNbParameters(); i++)
        {
            parameter_setType(i, BrickType.INTEGER);
        } 
        
        
        Color brickcolor = Color.getHSBColor(0.0f, 0.5f, 1.0f);
                
        setColor(brickcolor);
        
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("procedure"));
        brick_procedure_name.setColor(brickcolor);
        child_set(0, brick_procedure_name);
        
        if(parameters.length > 0)
        {
            if(parameters.length > 1)
                child_setString(1, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("parameters"));
            else
                child_setString(1, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("parameter"));
            
            for(int i = 0; i < parameters.length; i++)
            {
                parameters[i].setColor(brickcolor);
                child_set(1+i, parameters[i]);
            }
            
        }
        
        child_setString(1+parameters.length, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("does"));
        
        
        
        
    }
    
    
    public String getProcedureName()
    {
        return ((BrickWithText) child_get(0)).getText();
    }
    
    
    public String parameter_name_get(int num)
    {
        return ((BrickWithText) child_get(num+1)).getText();
    }
    
    
    public int getNbParameters()
    {
        return getNbChildren() - 2;
    }
    
    
    public Brick parameter_brick_get(int i)
    {
        return child_get(i+1);
    }
    
    public void parameter_setType(int i, BrickType bt)
    {
        child_setBrickType(1+i, bt);
    }
    
    public BrickType parameter_getType(int i)
    {
        return child_getBrickType(1+i);
    }
    
    
    public Brick Body_Brick_Get()
    {
        return child_get(getNbChildren() - 1);
    }
    
    public void Body_Brick_Set(Brick b)
    {
        child_set(getNbChildren() - 1, b);
    }
    
    
    
    @Override
    String execute_informations_supplementaires_get(Machine_Turtle aThis) {
        if(getNbParameters() == 0)
        {
            return "";
        }
        else
        {
            return String.valueOf( aThis.variable_getvalue(parameter_name_get(0)) );
        }
        
    }
    
    
    
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        if(Body_Brick_Get() != null)
            return Body_Brick_Get();
        else
             return mt.CallStack_PopPopAndGiveFuture();
    }
    
    
    
    
    
    
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(proc ");
        writer.write(String.valueOf(getNbParameters()));
        writer.write("\"" + getProcedureName() + "\"");

        for(int i = 0;i < getNbParameters(); i++)
        {
            writer.write("\"" + parameter_name_get(i) + "\"");
        }
        brick_sauvegarder_tenter(Body_Brick_Get(), writer);
        writer.write(")");
    }
    
    
    
    
    
    
    
    
    
    
    
}
