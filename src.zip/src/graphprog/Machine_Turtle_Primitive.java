/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.util.logging.Level;
import java.util.logging.Logger;





/**
 *
 * @author proprietaire
 */
public class Machine_Turtle_Primitive extends Thread {
    
    private int Delay_Between_Two_Instructions = 1000;
    private int Delay_Between_Two_Images = 50;
    private TurtleEnvironment turtle_environment = null;
    
    public enum Machine_Turtle_Speed {
        TURTLE, SHEEP, HORSE, CHEETAH;
    }
    
    public void setSpeed(Machine_Turtle_Speed speed)
    {
        switch(speed)
        {
            case TURTLE:
            {
                Delay_Between_Two_Instructions = 1000;
                Delay_Between_Two_Images = 50;
                break;
            }
            
            case SHEEP:
            {
                Delay_Between_Two_Instructions = 400;
                Delay_Between_Two_Images = 40;
                break;
            }
            
            case HORSE:
            {
                Delay_Between_Two_Instructions = 150;
                Delay_Between_Two_Images = 20;
                break;
            }
            
            case CHEETAH:
            {
                Delay_Between_Two_Instructions = 1;
                Delay_Between_Two_Images = 0;
                break;
            }
        }
                
     
    }
    
    public void Delay_Between_Two_Instructions_set(int newvalue) 
    {Delay_Between_Two_Instructions = newvalue;}
    
    public void dormir()
    {
        attendre(Delay_Between_Two_Instructions);
        
    }
    
    
    public void animation_attendre_entre_deux_images()
    {
        attendre(Delay_Between_Two_Images);
    }
    
    
    private void attendre(int nbmilli)
    {
        if(nbmilli > 0)
        try {
            Thread.sleep(nbmilli);
        } catch (InterruptedException ex) {
            Logger.getLogger(Machine_Turtle_Primitive.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    public Machine_Turtle_Primitive(TurtleEnvironment turtle_environment)
    {
        this.turtle_environment = turtle_environment;
        turtle_init_values();
    }
    
    
    public void turtle_init_values()
    {
        turtle_environment.turtle_x = 0;
        turtle_environment.turtle_y = 0;
        turtle_environment.turtle_direction_angle = 0;
        
        turtle_environment.drawing_clear();
        
        
    }
    
    
    
    public void turtle_init()
    {
         turtle_init_values();
         
         turtle_environment.repaint();
    }
    
    
    
    
    
    
    public void turtle_move_un_pas(double MoveLength)
    {
        
        turtle_environment.turtle_x += MoveLength*Math.cos(turtle_environment.turtle_direction_angle);
        turtle_environment.turtle_y += MoveLength*Math.sin(turtle_environment.turtle_direction_angle);
        
        turtle_environment.drawing_polygon_points_add(
                                  turtle_environment.turtle_x,
                                  turtle_environment.turtle_y);

        turtle_environment.repaint();
        
    }
    
    
    
    public void turtle_move_avec_animation(double MoveLength)
    {
        int animation_nbimages = 10;
        for(int i = 0; i < animation_nbimages; i++)
        {
            turtle_move_un_pas(MoveLength / ((double) animation_nbimages));
            animation_attendre_entre_deux_images();
        }
    }
    
    
    public void turtle_move(double MoveLength)
    {
        turtle_move_avec_animation(MoveLength);
    }
    
    
    
    public void turtle_turn_un_pas(double turn_angle_in_radian)
    {
        turtle_environment.turtle_direction_angle += turn_angle_in_radian;
        turtle_environment.repaint();
    }
    
    
    public void turtle_turn_avec_animation(double turn_angle_in_radian)
    {
        int animation_nbimages = 10;
        for(int i = 0; i < animation_nbimages; i++)
        {
            turtle_turn_un_pas(turn_angle_in_radian / ((double) animation_nbimages));
            animation_attendre_entre_deux_images();
        }
    }
    
    
    public void turtle_turn(double turn_angle_in_radian)
    {
        turtle_turn_avec_animation(turn_angle_in_radian);
    }
    
    
    public boolean Challenge_succeed()
    {
        return (turtle_environment.Challenge_succeed());

    }
    
    
    public boolean isChallenge()
    {
        return turtle_environment.isChallenge();
    }
    
    
    
    
}
