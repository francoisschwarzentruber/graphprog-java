/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickCall extends BrickWithSequence {
    public LIBrickCall(BrickWithText brick_procedure_name, int nbparameters)
    {
        super(2+nbparameters);
        
        child_setBrickType(0, BrickType.PROCEDURENAME);
        
        for(int i = 0; i < getNbParameters(); i++)
        {
            parameter_setType(i, BrickType.INTEGER);
        } 
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("call"));
        
        Color brickcolor = Color.getHSBColor(0.0f, 0.5f, 1.0f);        
        setColor(brickcolor);
        brick_procedure_name.setColor(brickcolor);
        child_set(0, brick_procedure_name);
        
        setBrick_width(48);
        
        

    }
    
    
    public LIBrickCall(BrickWithText brick_procedure_name, LIBrickProcedure procedure_brick)
    {
        super(2+procedure_brick.getNbParameters());
        
        child_setBrickType(0, BrickType.PROCEDURENAME);
        
        for(int i = 0; i < getNbParameters(); i++)
        {
            parameter_setType(i, BrickType.INTEGER);
        }  
        
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("call"));
        
        Color brickcolor = Color.getHSBColor(0.0f, 0.5f, 1.0f);        
        setColor(brickcolor);
        brick_procedure_name.setColor(brickcolor);
        
        child_set(0, brick_procedure_name);
        
        setBrick_width(48);
        
        for(int i = 0; i<procedure_brick.getNbParameters(); i++)
        {
            child_setString(1+i, procedure_brick.parameter_name_get(i) + java.util.ResourceBundle.getBundle("resources/LIBricks").getString("_="));
        }
    }        
    
    
    public String getProcedureName()
    {
        return ((BrickWithText) child_get(0)).getText();
    }
    
    
    public void parameter_set(int i, Brick b)
    {
        child_set(1+i, b);
    }
    
    
    public Brick parameter_get(int i)
    {
        return child_get(1+i);
    }    
    
    public void parameter_setType(int i, BrickType bt)
    {
        child_setBrickType(1+i, bt);
    }
    
    public BrickType parameter_getType(int i)
    {
        return child_getBrickType(1+i);
    }
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        Machine_Turtle_Information mti = new Machine_Turtle_Information(sequence_nextbrick_get());
        
        
        LIBrickProcedure brickprocedure = mt.getBrickProcedure(getProcedureName());
        
        if(brickprocedure == null)
        {
            // si je n'arrive pas à trouver la procédure que je veux appeler
            mt.execution_error(this, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("I_can_not_find_the_procedure_") +  getProcedureName() + java.util.ResourceBundle.getBundle("resources/LIBricks").getString("."));
            return null;
        }
        
        int nbparameters = brickprocedure.getNbParameters();
        
        for(int i = 0; i < nbparameters; i++)
        {
            if(parameter_get(i) == null)
            {
                mt.execution_error(this, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("The_parameter_") + brickprocedure.parameter_name_get(i) + java.util.ResourceBundle.getBundle("resources/LIBricks").getString("_is_missing."));
                mt.ValuePush(0);
            }
            else
                parameter_get(i).execute_and_return_future(mt);
            
            int v =  mt.ValuePop();
            mti.variable_setvalue(brickprocedure.parameter_name_get(i),
                                 v);
        }
        
        mt.CallStack_Push(mti);
        
        return brickprocedure;
    }

    private int getNbParameters() {
        return getNbChildren() - 2;
    }
    
    
        
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(call ");
        writer.write(String.valueOf(getNbParameters()));
        writer.write("\"" + getProcedureName() + "\"");

        for(int i = 0;i < getNbParameters(); i++)
        {
            brick_sauvegarder_tenter(parameter_get(i), writer);
        }

        brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
        writer.write(")");
    }
    
    
    
}