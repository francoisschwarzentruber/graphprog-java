/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

/**
 *
 * @author proprietaire
 */


import javax.sound.midi.*;
import java.net.URL;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JOptionPane;

class lectureMidi implements Runnable{
    Thread cadenceur = null;
    Sequence fichierSon = null;
    Sequencer lecteur = null;
    String cheminFichier = null;
    
    boolean stopped = false;
    
    public String getSoundName()
    {
        return cheminFichier;
    }
    
    public lectureMidi(String son) 
    {       
        this.cheminFichier = son;
        if (this.cadenceur == null) 
        {
            this.cadenceur = new Thread(this);
            this.cadenceur.start();
        }
        this.stopped = false;
    }

    public void run() 
    {
        try 
        {
            /*File file = new File(this.cheminFichier);
            this.fichierSon = MidiSystem.getSequence(file);*/
            
            URL url = getClass().getResource(cheminFichier);
            this.fichierSon = MidiSystem.getSequence(url);
            
            this.lecteur = MidiSystem.getSequencer();
            this.lecteur.open();
            this.lecteur.setSequence(fichierSon);
            this.lecteur.setLoopCount(Sequencer.LOOP_CONTINUOUSLY);
            this.lecteur.start();
            
            
            while (!stopped)//(this.lecteur.isRunning() && !stopped) 
            {
                try
                {
                    Thread.sleep(1000);
                } catch (InterruptedException e) { }
            }
            this.lecteur.close();
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, "Le fichier "+this.cheminFichier+" n'a pas pu etre lu", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void stop()
    {
        stopped = true;
    }
    
    
    public void play()
    {
        stopped = false;
        if(this.lecteur != null)
             this.lecteur.start();

    }
    
    public void pause()
    {
        this.lecteur.stop();
    }
    
    
    public void play_speed_factor_set(float factor)
    {
        this.lecteur.setTempoFactor(factor);
    }

}

public class Musique {
    static lectureMidi lectureMidiCourante = null;
    static Map lectureMidis = null;
    
    static void jouer(String name)
    {
        if(lectureMidis == null)
            lectureMidis = new TreeMap();
        
        for(Object l : lectureMidis.values())
        {
            ((lectureMidi) l).pause();
        }
            
        
        if(!lectureMidis.containsKey(name))
             lectureMidis.put(name, new lectureMidi(name));
        
        lectureMidiCourante = ((lectureMidi) lectureMidis.get(name));
        lectureMidiCourante.play();
    }
    
    
    
    static void jouer_vitesse_facteur_set(float facteur)
    {
        lectureMidiCourante.play_speed_factor_set(facteur);
    }
}
