/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package graphprog;


import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Area;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageOutputStream;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;


/**
 *
 * @author proprietaire
 */
public class ProgramPanel extends JPanel {

    
     public void modifierSourisCurseur(String img, Point hotSpot){
         //recupère le Toolkit, je ne sais pas à quoi ça correspond...
         Toolkit tk = Toolkit.getDefaultToolkit();
         //récupère l'image du curseur (stockée avec le .jar)
         Image image= tk.getImage(getClass().getResource(img));
         
         //crée un curseur avec l'image
         Cursor c = tk.createCustomCursor(image,hotSpot,"X");
         
         //puis on l'affecte
         setCursor(c);
     }
         
         
     public void modifierSourisCurseurMain()
     {
         modifierSourisCurseur("resources/main.png", new Point(4, 0));
     } 
     
     
     public void modifierSourisCurseurNormal()
     {
         setCursor(Cursor.getDefaultCursor());
     } 
    
    public class BrickInfoSupplementaire {
        private Brick brick = null;
        private String info_supplementaire = null;
        
        public BrickInfoSupplementaire(Brick brick, String info_supplementaire) {
            this.brick = brick;
            this.info_supplementaire = info_supplementaire;
        }
        
        public void draw(Graphics g)
        {
            brick.surimprimer_texte(g, info_supplementaire);
            
        }
        
    }
    
    private ActionListener connexionEntreBrique_EffetVisuel_arreter_action =
            new ActionListener()
                    {   
                        public void actionPerformed(ActionEvent event)
                        {
                            connexionEntreBrique_EffetVisuel_Arreter();
                            repaint();
                        }

                    };
                    
                    
    private Timer connexionEntreBrique_EffetVisuel_arreter_timer =
            new Timer(400,
                      connexionEntreBrique_EffetVisuel_arreter_action);
    
    private Point connexionEntreBrique_EffetVisuel_point = null;
    
    private Color fond_couleur = new Color(222, 222, 222);
    private ArrayList<Brick> liste = null;
    private int private_father_i = -1;
    private Brick private_match_child_brick = null;
    private Brick private_father_brick = null;
    
    private ImageIcon imgTrash = null;
    
    private ImageIcon imgClick = null;
    
    private URL sound_connexion_url;
    
    private Brick brick_highlighted = null;
    private String brick_highlighted_info_supplementaire = null;
    
    private Brick brick_under_mouse = null;

    private boolean trash_visible = true;
    private boolean connexionEntreBrique_EffetVisuel_isAfficher = false;
    
    private ArrayList<BrickInfoSupplementaire> infossupplementaires = null;
    
    
    public void setBrick_under_mouse(Brick brick_under_mouse) {
        this.brick_under_mouse = brick_under_mouse;
    }

    void noBrickHighLighted() {
        brick_highlighted = null;
        brick_highlighted_info_supplementaire = null;
    }
    
    void InfoSupplementaire_Ajouter(Brick brick, String info)
    {
        infossupplementaires.add(new BrickInfoSupplementaire(brick, info));
    }
    
    
    void InfoSupplementaire_Reset()
    {
        infossupplementaires = new ArrayList<BrickInfoSupplementaire>();
    }
    
    
    void InfoSupplementaire_Afficher(Graphics g)
    {
        for(BrickInfoSupplementaire i : infossupplementaires)
        {
            i.draw(g);
        }
    }
    

    private void connexionEntreBrique_EffetVisuel_afficher(Graphics g)
    {
        if(connexionEntreBrique_EffetVisuel_isAfficher)
        {
            g.drawImage(imgClick.getImage(), 
                        connexionEntreBrique_EffetVisuel_point.x,
                        connexionEntreBrique_EffetVisuel_point.y, this);
        }

    }
    
    
    
    
    private void connexionEntreBrique_EffetVisuel_Initialiser()
    {
        connexionEntreBrique_EffetVisuel_point = BrickMatchingConnexion_GetChildWhoMatches().getPos();
        connexionEntreBrique_EffetVisuel_point.x -= imgClick.getIconWidth() / 2;
        connexionEntreBrique_EffetVisuel_point.y -= imgClick.getIconHeight() / 2;
        connexionEntreBrique_EffetVisuel_isAfficher = true;
        connexionEntreBrique_EffetVisuel_arreter_timer.start();
    }
    
    
    
    private void connexionEntreBrique_EffetVisuel_Arreter()
    {
        connexionEntreBrique_EffetVisuel_isAfficher = false;
        connexionEntreBrique_EffetVisuel_arreter_timer.stop();
        
    }
    

    public ProgramPanel() {
        imgTrash = Images.get("/graphprog/resources/trash.png");
        imgClick = Images.get("/graphprog/resources/click.png");
        
        sound_connexion_url = Sounds.getURL("/graphprog/resources/metronome_tic.wav");
        
        modifierSourisCurseurNormal();
        Brick_ResetAll(); 
        InfoSupplementaire_Reset();
    }

    
    public void Brick_ResetAll()
    {
        liste = new ArrayList<Brick>();
        liste.clear();

        Brick brique_principale = new LIBrickMainProcedure();
        Brick_Insert(brique_principale);

    }
    
    public void Brick_Insert(Brick b) {
        if(getGraphics()!=null)
        {
             b.Width_Adapt(getGraphics().getFontMetrics());
        }
        liste.add(b);
    }

    
    
    public void Brick_Delete(Brick b) {
        if (b == null) {
            return;
        }

        //on ne peut pas supprimer la brique principale
        if (b instanceof LIBrickMainProcedure) {
            return;
        }

        //on supprime aussi les fils
        for (int i = 0; i < b.getNbChildren(); i++) {
            Brick_Delete(b.child_get(i));
        }

        //on le déconnecte
        b.disconnect();
        liste.remove(b);
    }

    public Brick Brick_under_xy(int x, int y) {
        for(int i = liste.size() - 1; i >= 0; i--)
        {
           Brick b = liste.get(i);
           if (b.xy_in_brick(x, y)) {
                return b;
            }
        }

        return null;
    }
    
    
    
    public void direCurseurIci(int x, int y)
    {
        if(Brick_under_xy(x, y) != null)
            modifierSourisCurseurMain();
        else
            modifierSourisCurseurNormal();
    }

    
    public void BrickMatchingConnexion_LookFor()
    {
        BrickMatchingConnexion_Nothing_Set();
        for (Brick brick_child : liste) 
        if(brick_child.IsOnTopLevel())
        {
            if(BrickMatchingConnexion_Brick_IsFatherMatch(brick_child,
                                                          brick_child.getPosx(),
                                                          brick_child.getPosy()))
                return;
        }
        
        BrickMatchingConnexion_Nothing_Set();
        
    }
    
    
    public boolean BrickMatchingConnexion_Brick_IsFatherMatch(Brick brick_child, int x, int y) {
        for (Brick brick_father : liste) {
            int socket = brick_father.IsFatherMatchAndGetSocket(brick_child, x, y);

            if (socket >= 0) {
                private_match_child_brick = brick_child;
                private_father_brick = brick_father;
                private_father_i = socket;
                return true;
            }
        }
        
        return false;
    }

    void Brick_TryMove(Brick brick_under_mouse, int newx, int newy) {
        brick_under_mouse.move(newx, newy);

    }
    
    
    
    private Brick BrickMatchingConnexion_GetFatherWhoMatches() {
        return private_father_brick;
    }

    private int BrickMatchingConnexion_GetFatherSocketWhoMatches() {
        return private_father_i;
    }
    
    private Brick BrickMatchingConnexion_GetChildWhoMatches() {
        return private_match_child_brick;
    }
    
    
    private void BrickMatchingConnexion_Nothing_Set()
    {
        private_father_brick = null;
    }
    
    private boolean BrickMatchingConnexion_Is_Nothing()
    {
        return (private_father_brick == null);
    }

    private Area SurfaceIntersectee_get(Brick brick_under_mouse) {
        
        Area a = new Area();
        java.awt.geom.Area mybrick_a = brick_under_mouse.getWholeArea();
        for(Brick b : liste)
        if(b.getTopLevelFather() != brick_under_mouse)
        {
            Area ai;
            
            ai = new Area(b.getPolygon());
            
            ai.intersect(mybrick_a);
            a.add(ai);
          
        }
        
        return a;

    }

    private void draw_background(Graphics g) {
        g.setColor(fond_couleur);
        g.fillRect(0, 0, getWidth(), getHeight());
    }

    private void draw_bricks(Graphics g) {
        for (Brick b : liste) {
            b.draw(g);
        }
    }

    private void draw_bricks_outline(Graphics2D g2) {
        g2.setStroke(new BasicStroke(2));
        g2.setComposite(makeComposite(0.7f));
        g2.setPaint(Color.black);
        for(Brick b : liste)
        if(b.IsOnTopLevel())
        {
            g2.draw(b.getWholeArea());
        }
    }

    private void draw_trash(Graphics g)
    {
        if(trash_visible)
        {
            g.drawImage(imgTrash.getImage(),
                    getWidth() - imgTrash.getIconWidth(),
                    getHeight() - imgTrash.getIconHeight(), this);
            
        }
    }
    
    
    private void draw_socket_cursor_who_if_matches(Graphics g)
    {
        if(BrickMatchingConnexion_GetFatherWhoMatches() != null)
        {
            BrickMatchingConnexion_GetFatherWhoMatches().draw_socketcursor(g, BrickMatchingConnexion_GetFatherSocketWhoMatches());
        }
    }

    private AlphaComposite makeComposite(float alpha) {
        int type = AlphaComposite.SRC_OVER;
        return(AlphaComposite.getInstance(type, alpha));
    }
    
    
    private void Graphics2Dconfigure(Graphics2D g2)
    {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
        RenderingHints.VALUE_RENDER_QUALITY);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        
        
        Graphics2D g2 = (Graphics2D) g;
        Graphics2Dconfigure(g2);
        
        draw_background(g);
        
        
        draw_trash(g);
        
        draw_bricks(g);
        
        draw_bricks_outline(g2);
        

        
        
        
        draw_socket_cursor_who_if_matches(g);
        
        connexionEntreBrique_EffetVisuel_afficher(g);
        
        
        if(brick_highlighted != null)
        {
            brick_highlighted.drawhighlight(g);
        }
        
        InfoSupplementaire_Afficher(g);
        
        
        if(!BrickMatchingConnexion_Is_Nothing())
        {
             g2.setStroke(new BasicStroke(3));
             g2.setComposite(makeComposite(0.8f));
             g2.setPaint(Color.blue);
             g2.draw(BrickMatchingConnexion_GetChildWhoMatches().getWholeArea());
             g2.drawPolygon(BrickMatchingConnexion_GetFatherWhoMatches().getPolygon());
        
        }
        
        
        

        
       

    }

    public void BrickMatchingConnexion_Brick_connect_ifgood() throws IOException {    


        BrickMatchingConnexion_LookFor();    
        if(!BrickMatchingConnexion_Is_Nothing())    
        {
            connexionEntreBrique_EffetVisuel_Initialiser();
            Sounds.get(sound_connexion_url).play();
            if((BrickMatchingConnexion_GetFatherWhoMatches() instanceof BrickWithSequence) && 
                    (BrickMatchingConnexion_GetFatherSocketWhoMatches() == BrickMatchingConnexion_GetFatherWhoMatches().getNbChildren()-1))
            {
                ((BrickWithSequence) BrickMatchingConnexion_GetFatherWhoMatches()).sequence_nextbrick_set(BrickMatchingConnexion_GetChildWhoMatches());
            }
            else
                BrickMatchingConnexion_GetFatherWhoMatches().child_set(
                        BrickMatchingConnexion_GetFatherSocketWhoMatches(),
                        BrickMatchingConnexion_GetChildWhoMatches());
            BrickMatchingConnexion_Nothing_Set(); 
        }
        
    }
    
    
    public Rectangle getPreferedSize()
    {
        return new Rectangle(0, 0, minwidth(), minheight());
    }
    
    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(minwidth(), minheight());
    } 
    
    public void calculateAll() {
        for (Brick b : liste) {
            if (b.IsOnTopLevel()) {
                b.position_calculer();
            }
        }
        setBounds(0, 0, minwidth(), minheight());
    }

    public Brick getBrickMainProcedure() {
        return liste.get(0);
    }

    public LIBrickProcedure getBrickProcedure(String name) {
        for (Brick b : liste) {
            if (b instanceof LIBrickProcedure) {
                if (((LIBrickProcedure) b).getProcedureName().equalsIgnoreCase(name)) {
                    return ((LIBrickProcedure) b);
                }

            }

        }
        return null;

    }
    
    
    
    public ArrayList<String> ProceduresName_get()
    {
        ArrayList<String> proceduresnames = new ArrayList<String>();
        
        for (Brick b : liste) {
            if (b instanceof LIBrickProcedure) {
                proceduresnames.add(((LIBrickProcedure) b).getProcedureName());
                
            }

        }
        
        return proceduresnames;
    }
    
    
    
    
    public List<String> getProceduresNames()
    {
        List<String> L = new ArrayList<String>();
        for (Brick b : liste) {
            if (b instanceof LIBrickProcedure) {
                L.add(
                          ((LIBrickProcedure) b).getProcedureName()
                     );     
            }
        }
        
        return L;
    }
    

    public boolean isMouseOverTrash(int x, int y) {
        if(trash_visible)
            return ((getWidth() - imgTrash.getIconWidth() < x)
             && (getHeight() - imgTrash.getIconHeight() < y));
        else
            return false;
    }
    
    
    public void setBrickHighLighted(Brick b)
    {
        brick_highlighted = b;
        
    }
    
    
    
    public void trash_setVisible(boolean trash_visible)
    {
        this.trash_visible = trash_visible;
        repaint();
    }
    
    
    public void programme_sauvegarder_fichier(String fichier_nom) throws IOException
    {
        BufferedWriter fichier = new BufferedWriter(new FileWriter(fichier_nom));
        programme_sauvegarder(fichier);
        fichier.close();
    }
    
    
    
    public void programme_image_sauvegarder_fichier(String fichier_nom) throws IOException
    {
       
        BufferedImage tamponSauvegarde = new BufferedImage(minwidth(),
                                                           minheight(),
                                                           BufferedImage.TYPE_3BYTE_BGR); 
        Graphics g = tamponSauvegarde.getGraphics();
        this.paint(g);
        ImageIO.write(tamponSauvegarde,
                      "PNG",
                      new FileImageOutputStream(new File(fichier_nom)));

    }
    
    
    public void programme_sauvegarder(BufferedWriter writer) throws IOException
    {
        for (Brick b : liste) {
            if (b.IsOnTopLevel())
            {
                writer.write("(setposition ");
                writer.write(String.valueOf(b.getPosx()));
                writer.write(" ");
                writer.write(String.valueOf(b.getPosy()));
                writer.write(")");
                writer.newLine();
                b.brick_sauvegarder(writer);
                writer.newLine();
            }
        }
    }
    
    
    
    public int minwidth()
    {
        int mw = 0;
        for(Brick b : liste)
        {
            int mwnew = (int) (b.getPosx() + b.getPolygon().getBounds().getWidth());
            if(mwnew > mw)
                mw = mwnew;
        }
        return mw;
    }
    
    
    public int minheight()
    {
        int mh = 0;
        for(Brick b : liste)
        {
            int mhnew = (int) (b.getPosy() + b.getPolygon().getBounds().getHeight());
            if(mhnew > mh)
                mh = mhnew;
        }
        return mh;
    }
    
}
