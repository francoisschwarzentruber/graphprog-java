/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package graphprog;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickWhile extends BrickWithSequence {
    public LIBrickWhile()
    {
        super(3);
        
        child_setBrickType(0, BrickType.BOOLEAN);
        child_setBrickType(1, BrickType.INSTRUCTION);
        
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("while"));
        child_setString(1, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("do"));
        
        setColor(Color.PINK);
    }
    
    
    
        
    public void condition_brick_set(Brick brick_condition)
    {
        child_set(0, brick_condition);
    }
    
    public Brick condition_brick_get()
    {
        return child_get(0);
    }
    
    
    public void body_while_brick_set(Brick brick)
    {
        child_set(1, brick);
    }
    
    public Brick body_while_brick_get()
    {
        return child_get(1);
    }
    
    
    @Override
    public void brick_sauvegarder(BufferedWriter writer) throws IOException
    {
        writer.write("(while ");
        brick_sauvegarder_tenter(condition_brick_get(), writer);
        brick_sauvegarder_tenter(body_while_brick_get(), writer);
        brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
        writer.write(")");
    }
    
}
