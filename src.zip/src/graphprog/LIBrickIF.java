/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author proprietaire
 */
public class LIBrickIF extends BrickWithSequence {
    public LIBrickIF()
    {
        super(3);
        
        child_setBrickType(0, BrickType.BOOLEAN);
        child_setBrickType(1, BrickType.INSTRUCTION);
        
        child_setString(0, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("if"));
        child_setString(1, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("then"));
        
        
        
        setColor(Color.ORANGE);
        
                
    }
    
    
    public void condition_brick_set(Brick brick_condition)
    {
        child_set(0, brick_condition);
    }
    
    public Brick condition_brick_get()
    {
        return child_get(0);
    }
    
    
    public void body_then_brick_set(Brick brick)
    {
        child_set(1, brick);
    }
    
    public Brick body_then_brick_get()
    {
        return child_get(1);
    }
    
    
    
    @Override
    public Brick execute_and_return_future(Machine_Turtle mt)
    {
        if(condition_brick_get() == null)
        {
            mt.execution_error(this, java.util.ResourceBundle.getBundle("resources/LIBricks").getString("The_brick_If_has_no_condition."));
            return null;
        }
        
        condition_brick_get().execute_and_return_future(mt);
        
        int condition_value = mt.ValuePop();
        
        Machine_Turtle_Information mti = new Machine_Turtle_Information(sequence_nextbrick_get());
        mt.CallStack_Push(mti);
        
        Brick future = null;
        
        if(condition_value != 0)
        {
            future = body_then_brick_get();
        
        }
        else
            future = null;
        
        
        if(future == null)
            return mt.CallStack_PopPopAndGiveFuture();
        else
            return future;
    }
    
    
    
        @Override
        public void brick_sauvegarder(BufferedWriter writer) throws IOException
        {
            writer.write("(if ");   
            brick_sauvegarder_tenter(condition_brick_get(), writer);
            brick_sauvegarder_tenter(body_then_brick_get(), writer);
            brick_sauvegarder_tenter(sequence_nextbrick_get(), writer);
            writer.write(")");
        }
    
    
}
