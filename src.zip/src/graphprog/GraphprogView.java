/*
 * GraphprogView.java
 */

package graphprog;

import graphprog.Machine_Turtle_Primitive.Machine_Turtle_Speed;
import java.awt.CardLayout;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.Icon;
import javax.swing.JFileChooser;

/**
 * The application's main frame.
 */
public class GraphprogView extends FrameView {
    private int LEVEL_NBLEVELS = 7;
    
    private Brick brick_under_mouse = null;
    private int brick_under_mouse_decallagex = 0;
    private int brick_under_mouse_decallagey = 0;
    private Machine_Turtle machine_turtle;
    private Machine_Turtle_View gpv;
    private int level = 1;
    private Machine_Turtle_Speed speed = Machine_Turtle_Speed.TURTLE;
    private String mission_name = null;
    
    
    
    public ProgramPanel GetmainPanel()
    {
        return ((ProgramPanel) mainPanel);
        
    }
    
    
    private TurtleEnvironment getTurtleEnvironment()
    {
        return ((TurtleEnvironment) turtle_environment);
        
    }

    private void imagelistchallenge_charger(int newlevel) {
        String challenge_fichier = null;
        
        try {
            BufferedReader fichier = null;

            fichier = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/graphprog/resources/challenges/level" + String.valueOf(newlevel) + ".txt")));

            while (fichier.ready()) {
                String ligne_lue = fichier.readLine();
                if(!ligne_lue.isEmpty())
                {
                    challenge_fichier = "challenges/" + ligne_lue;
                    imageListChallenge.add(challenge_fichier, challenge_fichier);
                }
            }
            fichier.close();
        } catch (IOException ex) {
            System.out.print("error with " + challenge_fichier);
        }
    } 
    
    
    
    private Machine_Turtle_Primitive.Machine_Turtle_Speed getMachineTurtleSpeed()
    {
        return this.speed;
    }
    
    
    
    private void setMachineTurtleSpeed(Machine_Turtle_Primitive.Machine_Turtle_Speed speed)
    {
        this.speed = speed;
        
        if(machine_turtle != null)
        {
            machine_turtle.setSpeed(speed);
        }
    }
    
    
    private void machine_turtle_init()
    {
        if(machine_turtle != null)
        {
            machine_turtle.finish();
            
        }

            gpv = new Machine_Turtle_View(this);
            machine_turtle = new Machine_Turtle(getTurtleEnvironment(),
                                            GetmainPanel(),
                                            gpv,
                                            this,
                                            getMachineTurtleSpeed());


    }
    
    private boolean isModeProgramingChallenge()
    {
        return panMission.isVisible();
    }
    
    
    public void Challenge_Succeed_Show()
    {
        
        if(isModeProgramingChallenge())
        {
            Musique.jouer("/graphprog/resources/musique_win.mid");
            CongratulationsDialog cd = new CongratulationsDialog(getFrame(), true);
            GraphprogApp.getApplication().show(cd);
            Inform_Stop();
        }
        
    }
    
    
    public void Challenge_Failed_Show()
    {
            Inform_Stop();
            lblMissionFailed.setVisible(true);
    }
    
    
    public GraphprogView(SingleFrameApplication app) {
        super(app);

        initComponents();
        
        lblMainPanelPositionCurseur.setVisible(false);
        lblExecutionError.setVisible(false);
        machine_turtle_init();
        setLevel(1);
        Mode_Title();
        
        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
               // statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        //statusAnimationLabel.setIcon(idleIcon);
        //progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        //statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    //progressBar.setVisible(true);
                    //progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                   // statusAnimationLabel.setIcon(idleIcon);
                   // progressBar.setVisible(false);
                   // progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                   // String text = (String)(evt.getNewValue());
                   // statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer)(evt.getNewValue());
                  ///  progressBar.setVisible(true);
                  //  progressBar.setIndeterminate(false);
                  //  progressBar.setValue(value);
                }
            }
        });
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = GraphprogApp.getApplication().getMainFrame();
            aboutBox = new GraphprogAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        GraphprogApp.getApplication().show(aboutBox);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panel_all = new javax.swing.JPanel();
        programing_panel_all = new javax.swing.JPanel();
        panel_topscreen = new javax.swing.JPanel();
        panMission = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblMission = new javax.swing.JTextArea();
        toobar_execution = new javax.swing.JToolBar();
        cmdExecute = new javax.swing.JButton();
        cmdStop = new javax.swing.JButton();
        toolbar_loadsave = new javax.swing.JToolBar();
        cmdLoad = new javax.swing.JButton();
        cmdSave = new javax.swing.JButton();
        toolbar_quit = new javax.swing.JToolBar();
        cmdMenu = new javax.swing.JButton();
        jSplitPane = new javax.swing.JSplitPane();
        turtle_environment = new TurtleEnvironment();
        lblMissionFailed = new javax.swing.JLabel();
        lblExecutionError = new javax.swing.JLabel();
        program_part = new javax.swing.JPanel();
        paneltools_container = new javax.swing.JPanel();
        paneltools_level1 = new PanelToolsLevel1(this);
        paneltools_level2 = new graphprog.PanelToolsLevel2(this);
        paneltools_level3 = new graphprog.PanelToolsLevel3(this);
        paneltools_level4 = new graphprog.PanelToolsLevel4(this);
        paneltools_level6 = new graphprog.PanelToolsLevel6(this);
        jScrollPane1 = new javax.swing.JScrollPane();
        mainPanel = new ProgramPanel();
        lblMainPanelPositionCurseur = new javax.swing.JLabel();
        logoTitlePanel = new graphprog.LogoTitlePanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panel_menu = new javax.swing.JPanel();
        panel_level = new javax.swing.JPanel();
        toolbar_level = new javax.swing.JToolBar();
        cmdLevelPrevious = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lblLevel1 = new javax.swing.JLabel();
        lblLevel = new javax.swing.JLabel();
        cmdLevelNext = new javax.swing.JButton();
        panel_menu_challenge = new javax.swing.JPanel();
        lblWhatdoyouwanttodraw = new javax.swing.JLabel();
        imageListChallenge = new graphprog.ImageList();
        toolbar_menu = new javax.swing.JToolBar();
        cmdIwanttodrawmyownprogram = new javax.swing.JButton();
        jPopupMenuTurtleEnvironment = new javax.swing.JPopupMenu();
        mnuTurtleVisible = new javax.swing.JRadioButtonMenuItem();
        mnuTurtleInvisible = new javax.swing.JRadioButtonMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        mnuChangeSpeed = new javax.swing.JMenuItem();
        buttonGroupTurtleEnvironmentTurtleVisible = new javax.swing.ButtonGroup();
        buttonGroupTurtleMachineSpeed = new javax.swing.ButtonGroup();

        panel_all.setName("panel_all"); // NOI18N
        panel_all.setLayout(new java.awt.CardLayout());

        programing_panel_all.setName("programing_panel_all"); // NOI18N

        panel_topscreen.setName("panel_topscreen"); // NOI18N
        panel_topscreen.setLayout(new javax.swing.BoxLayout(panel_topscreen, javax.swing.BoxLayout.X_AXIS));

        panMission.setMinimumSize(new java.awt.Dimension(100, 32));
        panMission.setName("panMission"); // NOI18N
        panMission.setPreferredSize(new java.awt.Dimension(100, 32));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11));
        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(graphprog.GraphprogApp.class).getContext().getResourceMap(GraphprogView.class);
        jLabel1.setText(resourceMap.getString("text")); // NOI18N
        jLabel1.setName(""); // NOI18N

        lblMission.setColumns(20);
        lblMission.setEditable(false);
        lblMission.setLineWrap(true);
        lblMission.setRows(5);
        lblMission.setText(resourceMap.getString("lblMission.text")); // NOI18N
        lblMission.setName("lblMission"); // NOI18N
        lblMission.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMissionMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panMissionLayout = new javax.swing.GroupLayout(panMission);
        panMission.setLayout(panMissionLayout);
        panMissionLayout.setHorizontalGroup(
            panMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panMissionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblMission, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE))
        );
        panMissionLayout.setVerticalGroup(
            panMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panMissionLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblMission, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel_topscreen.add(panMission);

        toobar_execution.setFloatable(false);
        toobar_execution.setRollover(true);
        toobar_execution.setName("toobar_execution"); // NOI18N

        cmdExecute.setIcon(resourceMap.getIcon("cmdExecute.icon")); // NOI18N
        cmdExecute.setText(resourceMap.getString("cmdExecute.text")); // NOI18N
        cmdExecute.setFocusable(false);
        cmdExecute.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdExecute.setName("cmdExecute"); // NOI18N
        cmdExecute.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdExecuteActionPerformed(evt);
            }
        });
        toobar_execution.add(cmdExecute);

        cmdStop.setIcon(resourceMap.getIcon("cmdStop.icon")); // NOI18N
        cmdStop.setText(resourceMap.getString("cmdStop.text")); // NOI18N
        cmdStop.setFocusable(false);
        cmdStop.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdStop.setName("cmdStop"); // NOI18N
        cmdStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdStopActionPerformed(evt);
            }
        });
        toobar_execution.add(cmdStop);

        panel_topscreen.add(toobar_execution);

        toolbar_loadsave.setFloatable(false);
        toolbar_loadsave.setRollover(true);
        toolbar_loadsave.setName("toolbar_loadsave"); // NOI18N

        cmdLoad.setIcon(resourceMap.getIcon("cmdLoad.icon")); // NOI18N
        cmdLoad.setText(resourceMap.getString("cmdLoad.text")); // NOI18N
        cmdLoad.setFocusable(false);
        cmdLoad.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdLoad.setName("cmdLoad"); // NOI18N
        cmdLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdLoadActionPerformed(evt);
            }
        });
        toolbar_loadsave.add(cmdLoad);

        cmdSave.setIcon(resourceMap.getIcon("cmdSave.icon")); // NOI18N
        cmdSave.setText(resourceMap.getString("cmdSave.text")); // NOI18N
        cmdSave.setFocusable(false);
        cmdSave.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdSave.setName("cmdSave"); // NOI18N
        cmdSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdSaveActionPerformed(evt);
            }
        });
        toolbar_loadsave.add(cmdSave);

        panel_topscreen.add(toolbar_loadsave);

        toolbar_quit.setFloatable(false);
        toolbar_quit.setRollover(true);
        toolbar_quit.setName("toolbar_quit"); // NOI18N

        cmdMenu.setIcon(resourceMap.getIcon("cmdMenu.icon")); // NOI18N
        cmdMenu.setText(resourceMap.getString("cmdMenu.text")); // NOI18N
        cmdMenu.setFocusable(false);
        cmdMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdMenu.setName("cmdMenu"); // NOI18N
        cmdMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdMenuActionPerformed(evt);
            }
        });
        toolbar_quit.add(cmdMenu);

        panel_topscreen.add(toolbar_quit);

        jSplitPane.setName("jSplitPane"); // NOI18N

        turtle_environment.setBackground(resourceMap.getColor("turtle_environment.background")); // NOI18N
        turtle_environment.setName("turtle_environment"); // NOI18N
        turtle_environment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                turtle_environmentMouseClicked(evt);
            }
        });

        lblMissionFailed.setFont(resourceMap.getFont("lblMissionFailed.font")); // NOI18N
        lblMissionFailed.setText(resourceMap.getString("lblMissionFailed.text")); // NOI18N
        lblMissionFailed.setName("lblMissionFailed"); // NOI18N

        lblExecutionError.setFont(resourceMap.getFont("lblExecutionError.font")); // NOI18N
        lblExecutionError.setForeground(resourceMap.getColor("lblExecutionError.foreground")); // NOI18N
        lblExecutionError.setText(resourceMap.getString("lblExecutionError.text")); // NOI18N
        lblExecutionError.setName("lblExecutionError"); // NOI18N

        javax.swing.GroupLayout turtle_environmentLayout = new javax.swing.GroupLayout(turtle_environment);
        turtle_environment.setLayout(turtle_environmentLayout);
        turtle_environmentLayout.setHorizontalGroup(
            turtle_environmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(turtle_environmentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMissionFailed, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(360, Short.MAX_VALUE))
            .addComponent(lblExecutionError, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)
        );
        turtle_environmentLayout.setVerticalGroup(
            turtle_environmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(turtle_environmentLayout.createSequentialGroup()
                .addComponent(lblExecutionError)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblMissionFailed)
                .addContainerGap(528, Short.MAX_VALUE))
        );

        jSplitPane.setRightComponent(turtle_environment);

        program_part.setName("program_part"); // NOI18N
        program_part.setLayout(new javax.swing.BoxLayout(program_part, javax.swing.BoxLayout.LINE_AXIS));

        paneltools_container.setBackground(resourceMap.getColor("paneltools_container.background")); // NOI18N
        paneltools_container.setMaximumSize(new java.awt.Dimension(90, 2147483647));
        paneltools_container.setName("paneltools_container"); // NOI18N
        paneltools_container.setLayout(new java.awt.CardLayout());

        paneltools_level1.setName("paneltools_level1"); // NOI18N
        paneltools_container.add(paneltools_level1, "paneltools_level1");

        paneltools_level2.setName("paneltools_level2"); // NOI18N
        paneltools_container.add(paneltools_level2, "paneltools_level2");

        paneltools_level3.setName("paneltools_level3"); // NOI18N
        paneltools_container.add(paneltools_level3, "paneltools_level3");

        paneltools_level4.setName("paneltools_level4"); // NOI18N
        paneltools_container.add(paneltools_level4, "paneltools_level4");

        paneltools_level6.setName("paneltools_level6"); // NOI18N
        paneltools_container.add(paneltools_level6, "paneltools_level6");

        program_part.add(paneltools_container);

        jScrollPane1.setBorder(null);
        jScrollPane1.setName("jScrollPane1"); // NOI18N

        mainPanel.setBackground(resourceMap.getColor("mainPanel.background")); // NOI18N
        mainPanel.setMinimumSize(new java.awt.Dimension(300, 0));
        mainPanel.setName("mainPanel"); // NOI18N
        mainPanel.setPreferredSize(mainPanel.getPreferredSize());
        mainPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mainPanelMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                mainPanelMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                mainPanelMouseReleased(evt);
            }
        });
        mainPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                mainPanelMouseDragged(evt);
            }
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                mainPanelMouseMoved(evt);
            }
        });
        mainPanel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mainPanelKeyPressed(evt);
            }
        });

        lblMainPanelPositionCurseur.setForeground(resourceMap.getColor("lblMainPanelPositionCurseur.foreground")); // NOI18N
        lblMainPanelPositionCurseur.setText(resourceMap.getString("lblMainPanelPositionCurseur.text")); // NOI18N
        lblMainPanelPositionCurseur.setName("lblMainPanelPositionCurseur"); // NOI18N

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addComponent(lblMainPanelPositionCurseur, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(289, Short.MAX_VALUE))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addComponent(lblMainPanelPositionCurseur)
                .addContainerGap(537, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(mainPanel);

        program_part.add(jScrollPane1);

        jSplitPane.setLeftComponent(program_part);

        javax.swing.GroupLayout programing_panel_allLayout = new javax.swing.GroupLayout(programing_panel_all);
        programing_panel_all.setLayout(programing_panel_allLayout);
        programing_panel_allLayout.setHorizontalGroup(
            programing_panel_allLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane, javax.swing.GroupLayout.DEFAULT_SIZE, 640, Short.MAX_VALUE)
            .addComponent(panel_topscreen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 640, Short.MAX_VALUE)
        );
        programing_panel_allLayout.setVerticalGroup(
            programing_panel_allLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(programing_panel_allLayout.createSequentialGroup()
                .addComponent(panel_topscreen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSplitPane, javax.swing.GroupLayout.PREFERRED_SIZE, 569, Short.MAX_VALUE))
        );

        panel_all.add(programing_panel_all, "programing_panel");

        logoTitlePanel.setName("logoTitlePanel"); // NOI18N
        logoTitlePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoTitlePanelMouseClicked(evt);
            }
        });

        jPanel2.setName("jPanel2"); // NOI18N
        jPanel2.setLayout(new java.awt.GridBagLayout());

        jLabel2.setBackground(resourceMap.getColor("jLabel2.background")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel2.add(jLabel2, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        logoTitlePanel.add(jPanel2, gridBagConstraints);

        panel_all.add(logoTitlePanel, "title");

        panel_menu.setName("panel_menu"); // NOI18N
        panel_menu.setLayout(new javax.swing.BoxLayout(panel_menu, javax.swing.BoxLayout.Y_AXIS));

        panel_level.setName("panel_level"); // NOI18N
        panel_level.setLayout(new javax.swing.BoxLayout(panel_level, javax.swing.BoxLayout.Y_AXIS));

        toolbar_level.setFloatable(false);
        toolbar_level.setRollover(true);
        toolbar_level.setName("toolbar_level"); // NOI18N

        cmdLevelPrevious.setIcon(resourceMap.getIcon("cmdLevelPrevious.icon")); // NOI18N
        cmdLevelPrevious.setText(resourceMap.getString("cmdLevelPrevious.text")); // NOI18N
        cmdLevelPrevious.setFocusable(false);
        cmdLevelPrevious.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cmdLevelPrevious.setName("cmdLevelPrevious"); // NOI18N
        cmdLevelPrevious.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cmdLevelPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdLevelPreviousActionPerformed(evt);
            }
        });
        toolbar_level.add(cmdLevelPrevious);

        jPanel1.setName("jPanel1"); // NOI18N
        jPanel1.setLayout(new java.awt.GridBagLayout());

        lblLevel1.setFont(resourceMap.getFont("lblLevel1.font")); // NOI18N
        lblLevel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLevel1.setIcon(resourceMap.getIcon("lblLevel1.icon")); // NOI18N
        lblLevel1.setText(resourceMap.getString("lblLevel1.text")); // NOI18N
        lblLevel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblLevel1.setIconTextGap(20);
        lblLevel1.setName("lblLevel1"); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel1.add(lblLevel1, gridBagConstraints);

        lblLevel.setFont(resourceMap.getFont("lblLevel.font")); // NOI18N
        lblLevel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLevel.setText(resourceMap.getString("lblLevel.text")); // NOI18N
        lblLevel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblLevel.setIconTextGap(20);
        lblLevel.setName("lblLevel"); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        jPanel1.add(lblLevel, gridBagConstraints);

        toolbar_level.add(jPanel1);

        cmdLevelNext.setIcon(resourceMap.getIcon("cmdLevelNext.icon")); // NOI18N
        cmdLevelNext.setText(resourceMap.getString("cmdLevelNext.text")); // NOI18N
        cmdLevelNext.setFocusable(false);
        cmdLevelNext.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cmdLevelNext.setName("cmdLevelNext"); // NOI18N
        cmdLevelNext.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cmdLevelNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdLevelNextActionPerformed(evt);
            }
        });
        toolbar_level.add(cmdLevelNext);

        panel_level.add(toolbar_level);

        panel_menu.add(panel_level);

        panel_menu_challenge.setName("panel_menu_challenge"); // NOI18N
        panel_menu_challenge.setLayout(new javax.swing.BoxLayout(panel_menu_challenge, javax.swing.BoxLayout.PAGE_AXIS));

        lblWhatdoyouwanttodraw.setFont(resourceMap.getFont("lblWhatdoyouwanttodraw.font")); // NOI18N
        lblWhatdoyouwanttodraw.setText(resourceMap.getString("lblWhatdoyouwanttodraw.text")); // NOI18N
        lblWhatdoyouwanttodraw.setName("lblWhatdoyouwanttodraw"); // NOI18N
        panel_menu_challenge.add(lblWhatdoyouwanttodraw);

        imageListChallenge.setMinimumSize(new java.awt.Dimension(200, 100));
        imageListChallenge.setName("imageListChallenge"); // NOI18N
        imageListChallenge.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                imageListChallengeMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout imageListChallengeLayout = new javax.swing.GroupLayout(imageListChallenge);
        imageListChallenge.setLayout(imageListChallengeLayout);
        imageListChallengeLayout.setHorizontalGroup(
            imageListChallengeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 640, Short.MAX_VALUE)
        );
        imageListChallengeLayout.setVerticalGroup(
            imageListChallengeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 422, Short.MAX_VALUE)
        );

        panel_menu_challenge.add(imageListChallenge);

        toolbar_menu.setFloatable(false);
        toolbar_menu.setRollover(true);
        toolbar_menu.setBorderPainted(false);
        toolbar_menu.setName("toolbar_menu"); // NOI18N

        cmdIwanttodrawmyownprogram.setFont(resourceMap.getFont("cmdIwanttodrawmyownprogram.font")); // NOI18N
        cmdIwanttodrawmyownprogram.setIcon(resourceMap.getIcon("cmdIwanttodrawmyownprogram.icon")); // NOI18N
        cmdIwanttodrawmyownprogram.setText(resourceMap.getString("cmdIwanttodrawmyownprogram.text")); // NOI18N
        cmdIwanttodrawmyownprogram.setFocusable(false);
        cmdIwanttodrawmyownprogram.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdIwanttodrawmyownprogram.setName("cmdIwanttodrawmyownprogram"); // NOI18N
        cmdIwanttodrawmyownprogram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdIwanttodrawmyownprogramActionPerformed(evt);
            }
        });
        toolbar_menu.add(cmdIwanttodrawmyownprogram);

        panel_menu_challenge.add(toolbar_menu);

        panel_menu.add(panel_menu_challenge);

        panel_all.add(panel_menu, "menu_panel");

        jPopupMenuTurtleEnvironment.setComponentPopupMenu(jPopupMenuTurtleEnvironment);
        jPopupMenuTurtleEnvironment.setName("jPopupMenuTurtleEnvironment"); // NOI18N

        buttonGroupTurtleEnvironmentTurtleVisible.add(mnuTurtleVisible);
        mnuTurtleVisible.setSelected(true);
        mnuTurtleVisible.setText(resourceMap.getString("mnuTurtleVisible.text")); // NOI18N
        mnuTurtleVisible.setName("mnuTurtleVisible"); // NOI18N
        mnuTurtleVisible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuTurtleVisibleActionPerformed(evt);
            }
        });
        jPopupMenuTurtleEnvironment.add(mnuTurtleVisible);

        buttonGroupTurtleEnvironmentTurtleVisible.add(mnuTurtleInvisible);
        mnuTurtleInvisible.setText(resourceMap.getString("mnuTurtleInvisible.text")); // NOI18N
        mnuTurtleInvisible.setName("mnuTurtleInvisible"); // NOI18N
        mnuTurtleInvisible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuTurtleInvisibleActionPerformed(evt);
            }
        });
        jPopupMenuTurtleEnvironment.add(mnuTurtleInvisible);

        jSeparator1.setName("jSeparator1"); // NOI18N
        jPopupMenuTurtleEnvironment.add(jSeparator1);

        mnuChangeSpeed.setText(resourceMap.getString("mnuChangeSpeed.text")); // NOI18N
        mnuChangeSpeed.setName("mnuChangeSpeed"); // NOI18N
        mnuChangeSpeed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuChangeSpeedActionPerformed(evt);
            }
        });
        jPopupMenuTurtleEnvironment.add(mnuChangeSpeed);

        jPopupMenuTurtleEnvironment.getAccessibleContext().setAccessibleParent(turtle_environment);

        setComponent(panel_all);
    }// </editor-fold>//GEN-END:initComponents
    
    private void mainPanelMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseMoved
        // TODO add your handling code here:
        //if(evt.getButton() == java.awt.event.MouseEvent.NOBUTTON)
        
            GetmainPanel().direCurseurIci(evt.getX(), evt.getY());    
        
            if(isModeAjoutBrique())
            {
                mainPanelMouseDragged(evt);
                
            }
            else
            {
                brick_under_mouse = ((ProgramPanel) mainPanel).Brick_under_xy(evt.getX(),evt.getY());
                
                if(brick_under_mouse != null)
                {
                        brick_under_mouse_decallagex = evt.getX() - brick_under_mouse.getPosx();
                        brick_under_mouse_decallagey = evt.getY() - brick_under_mouse.getPosy();
                }
                
                
                
            }
            
            lblMainPanelPositionCurseur.setText("x = " + String.valueOf(evt.getX()) + ", y = " + String.valueOf(evt.getY()));
            
    }//GEN-LAST:event_mainPanelMouseMoved

    private void mainPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseDragged
        // TODO add your handling code here:
        if (brick_under_mouse != null)
        {
                GetmainPanel().setBrick_under_mouse(brick_under_mouse);

                int newx = evt.getX() - brick_under_mouse_decallagex;
                int newy = evt.getY() - brick_under_mouse_decallagey;

                if (newx < 0) {
                    newx = 0;
                }

                if (newy < 0) {
                    newy = 0;
                }

                GetmainPanel().Brick_TryMove(brick_under_mouse, newx, newy);
                


                //GetmainPanel().Brick_see_if_there_is_possible_connexion(brick_under_mouse, brick_under_mouse.getPosx(), brick_under_mouse.getPosy());
                GetmainPanel().BrickMatchingConnexion_LookFor();
                mainPanel.repaint();
            

        }
        else
            GetmainPanel().setBrick_under_mouse(null);
    }//GEN-LAST:event_mainPanelMouseDragged

    private boolean private_modeajoutbrique = false;
    
    public void NouvelleBrique(Brick b)
    {
        private_modeajoutbrique = true;
        brick_under_mouse = b;
        b.move(100, 100);
        GetmainPanel().Brick_Insert(brick_under_mouse);
        GetmainPanel().repaint();
    }
    
    private void mainPanelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseReleased
        // TODO add your handling code here:
        ModeAjoutBrique_Fin();
        GetmainPanel().setBrick_under_mouse(null);
        if(GetmainPanel().isMouseOverTrash(evt.getX(), evt.getY()))
        {
            
            GetmainPanel().Brick_Delete(brick_under_mouse);
            GetmainPanel().repaint();
        }
        else
        {
            try {
                GetmainPanel().BrickMatchingConnexion_Brick_connect_ifgood();
                GetmainPanel().calculateAll();
                GetmainPanel().repaint();
            } catch (IOException ex) {
                Logger.getLogger(GraphprogView.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }//GEN-LAST:event_mainPanelMouseReleased

    
    public void execution_error(String s)
    {
         lblExecutionError.setText(s);
         lblExecutionError.setVisible(true);
    }
    
    
    public void Inform_Execute()
    {
        cmdExecute.setVisible(false);
        cmdStop.setVisible(true);
        lblMissionFailed.setVisible(false);
        lblExecutionError.setVisible(false);
        
        Musique.jouer("/graphprog/resources/musique_program_run.mid");
    }
    
    
    public void Inform_Stop()
    {
        cmdExecute.setVisible(true);
        cmdStop.setVisible(false);
        
        Musique.jouer("/graphprog/resources/musique_program_creation.mid");
    }
    
    

    
    private void mainPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseClicked
        // TODO add your handling code here:

        if(evt.getClickCount() > 1)
        {
            if(brick_under_mouse != null)
            {
                machine_turtle_init();
                machine_turtle.setBrickToExecute(brick_under_mouse);
                machine_turtle.start();
            }
        }
        
        
    }//GEN-LAST:event_mainPanelMouseClicked

    
    
    private int getLevel()
    {
        return level;
    
    }
    
    
    private void setLevel(int newlevel)
    {
        level = newlevel;
        lblLevel.setText(java.util.ResourceBundle.getBundle("resources/GUI").getString("Level_") + String.valueOf(newlevel));
        CardLayout cl = ((CardLayout) paneltools_container.getLayout());
        
        switch (newlevel) {
            case 1: 
                cl.show(paneltools_container, "paneltools_level1");
                Brick.setBricks_OneLine_Height(32);
                machine_turtle.Delay_Between_Two_Instructions_set(1000);
                break;
            
            case 2: 
                cl.show(paneltools_container, "paneltools_level2");
                Brick.setBricks_OneLine_Height(32);
                machine_turtle.Delay_Between_Two_Instructions_set(1000);
                break;
            
            case 3: case 4: 
                cl.show(paneltools_container, "paneltools_level3");
                Brick.setBricks_OneLine_Height(24);
                machine_turtle.Delay_Between_Two_Instructions_set(1000);
                break;


            case 5: 
                cl.show(paneltools_container, "paneltools_level4");
                Brick.setBricks_OneLine_Height(24);
                machine_turtle.Delay_Between_Two_Instructions_set(100);
                break;
            
            case 6: 
            cl.show(paneltools_container, "paneltools_level6");
            Brick.setBricks_OneLine_Height(24);
            machine_turtle.Delay_Between_Two_Instructions_set(10);
            break;
            
            case 7: 
            cl.show(paneltools_container, "paneltools_level6");
            Brick.setBricks_OneLine_Height(21);
            machine_turtle.Delay_Between_Two_Instructions_set(5);
            break;
            
        }
        
        
       imageListChallenge.clear();
       
       imagelistchallenge_charger(newlevel);

       imageListChallenge.repaint();
        
    }
    
    private void cmdExecuteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdExecuteActionPerformed
        // TODO add your handling code here:
        cmdExecute.setVisible(false);
        cmdStop.setVisible(true);
        
        machine_turtle_init();
        machine_turtle.setBrickToExecute(GetmainPanel().getBrickMainProcedure());
        machine_turtle.start();
    }//GEN-LAST:event_cmdExecuteActionPerformed

    private void cmdStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdStopActionPerformed
        // TODO add your handling code here:
        machine_turtle.finish();
    }//GEN-LAST:event_cmdStopActionPerformed

    private void ChallengeModeOn(String challenge_name)
    {
        GetmainPanel().trash_setVisible(false);
        paneltools_container.setVisible(false);
        
        mission_name = challenge_name;
        
        Challenge c = new Challenge(GetmainPanel(), challenge_name);
        
        getTurtleEnvironment().setChallenge(c);
        getTurtleEnvironment().reset();
        
        lblMission.setText(c.mission_text_get());
        panMission.setVisible(true);
        toolbar_loadsave.setVisible(false);
        Mode_Programing();
    }
    
    
    
    private boolean ChallengeMode_IsOn()
    {
          return panMission.isVisible();  
    }
    
    
    
    private void ChallengeModeOff()
    {
        GetmainPanel().trash_setVisible(true);
        paneltools_container.setVisible(true);
        
        GetmainPanel().Brick_ResetAll();
        getTurtleEnvironment().NoChallenge();
        getTurtleEnvironment().reset();
        panMission.setVisible(false);
        toolbar_loadsave.setVisible(true);
        Mode_Programing();
        
    }
    
    
    
    private void cmdIwanttodrawmyownprogramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdIwanttodrawmyownprogramActionPerformed
        // TODO add your handling code here:
        ChallengeModeOff();
}//GEN-LAST:event_cmdIwanttodrawmyownprogramActionPerformed

    
    private void Mode_Title()
    {
        CardLayout cl = ((CardLayout) panel_all.getLayout());
        cl.show(panel_all, "title");
        Musique.jouer("/graphprog/resources/musique_title.mid");
    }
    
    private void Mode_Menu()
    {
        CardLayout cl = ((CardLayout) panel_all.getLayout());
        cl.show(panel_all, "menu_panel");
        Musique.jouer("/graphprog/resources/musique_menu.mid");
    }
    

    
    private void Mode_Programing()
    {
        CardLayout cl = ((CardLayout) panel_all.getLayout());
        cl.show(panel_all, "programing_panel");
        machine_turtle_init();
        lblExecutionError.setVisible(false);
        lblMissionFailed.setVisible(false);
        Inform_Stop();
    }
    
    private void cmdMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdMenuActionPerformed
        // TODO add your handling code here:
        QuitConfirmationDialog md = new QuitConfirmationDialog(getFrame(), true);
        GraphprogApp.getApplication().show(md);
        
        if(md.getDialog_result()) {
            Mode_Menu();
        }
    }//GEN-LAST:event_cmdMenuActionPerformed

    private void imageListChallengeMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imageListChallengeMouseReleased
        // TODO add your handling code here:
        String str = imageListChallenge.getElementName(evt.getX());
        
        if(str != null)
        {
            ChallengeModeOn(str);
            
        }
    }//GEN-LAST:event_imageListChallengeMouseReleased

    private void cmdLevelNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdLevelNextActionPerformed
        // TODO add your handling code here:
        if(getLevel() < LEVEL_NBLEVELS)
            setLevel(getLevel() + 1);
    }//GEN-LAST:event_cmdLevelNextActionPerformed

    private void cmdLevelPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdLevelPreviousActionPerformed
        // TODO add your handling code here:
        if(getLevel() > 1)
            setLevel(getLevel() - 1);
    }//GEN-LAST:event_cmdLevelPreviousActionPerformed

    private void mainPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMousePressed
        // TODO add your handling code here:
        if(brick_under_mouse != null)
        {
            brick_under_mouse.disconnect();
        }
        
    }//GEN-LAST:event_mainPanelMousePressed

    private void mainPanelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainPanelKeyPressed
        // TODO add your handling code here:
        if(java.awt.event.KeyEvent.VK_F2 == evt.getKeyCode())
        {
            lblMainPanelPositionCurseur.setVisible(!lblMainPanelPositionCurseur.isVisible());
        }
        
        if(java.awt.event.KeyEvent.VK_F3 == evt.getKeyCode())
        {
            
            getTurtleEnvironment().turtle_setvisible(getTurtleEnvironment().turtle_isvisible());
        }
    }//GEN-LAST:event_mainPanelKeyPressed

    private void logoTitlePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoTitlePanelMouseClicked
        // TODO add your handling code here:
        Mode_Menu();
    }//GEN-LAST:event_logoTitlePanelMouseClicked

    private void mainPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseEntered
        GetmainPanel().setBrick_under_mouse(brick_under_mouse);
                GetmainPanel().repaint();
    }//GEN-LAST:event_mainPanelMouseEntered

    private void cmdLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdLoadActionPerformed
        programme_courant_ouvrir();
}//GEN-LAST:event_cmdLoadActionPerformed

    private void cmdSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdSaveActionPerformed
        programme_courant_sauvegarder();
        
}//GEN-LAST:event_cmdSaveActionPerformed

    private void mnuTurtleVisibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuTurtleVisibleActionPerformed
        // TODO add your handling code here:
        getTurtleEnvironment().turtle_setvisible(true);
    }//GEN-LAST:event_mnuTurtleVisibleActionPerformed

    private void mnuTurtleInvisibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuTurtleInvisibleActionPerformed
        // TODO add your handling code here:
        getTurtleEnvironment().turtle_setvisible(false);
    }//GEN-LAST:event_mnuTurtleInvisibleActionPerformed

    private void turtle_environmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_turtle_environmentMouseClicked
        // TODO add your handling code here:
        if(evt.getButton() == (java.awt.event.MouseEvent.BUTTON3)) {
                jPopupMenuTurtleEnvironment.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_turtle_environmentMouseClicked

private void mnuChangeSpeedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuChangeSpeedActionPerformed
// TODO add your handling code here:
    MachineTurtleSpeedDialog d = new MachineTurtleSpeedDialog(getFrame(), true);
    d.setVisible(true);
    
    if(d.getDialog_result())
    {
        setMachineTurtleSpeed(d.getSpeed());
    }
    
}//GEN-LAST:event_mnuChangeSpeedActionPerformed

private void lblMissionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMissionMouseClicked
// TODO add your handling code here:
    HelpDialog hd = new HelpDialog(getFrame(), true);
    hd.page_show("resources/" + mission_name + ".html");
    hd.setVisible(true);
}//GEN-LAST:event_lblMissionMouseClicked

    
    private void programme_courant_ouvrir()
    {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Ouvrir un programme...");
        if(fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            Mode_Programing();
            ChallengeModeOff();
            ProgramPanelOpenFromFile ppof = new ProgramPanelOpenFromFile(GetmainPanel());
            ppof.programme_charger(fc.getSelectedFile().getAbsolutePath());
        }
    }
    
    private void programme_courant_sauvegarder()
    {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Enregistrer mon programme sous le fichier...");
        if(fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            try {
                GetmainPanel().programme_sauvegarder_fichier(fc.getSelectedFile().getAbsolutePath());                                       
                //GetmainPanel().programme_image_sauvegarder_fichier("sauvegarde_de_mon_programme.png"); 
    //sauvegarder l'image
            } catch (IOException ex) {
                Logger.getLogger(GraphprogView.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    private boolean isModeAjoutBrique()
    {
        return private_modeajoutbrique;
    }
    
    private void ModeAjoutBrique_Fin()
    {
        private_modeajoutbrique = false;
        
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroupTurtleEnvironmentTurtleVisible;
    private javax.swing.ButtonGroup buttonGroupTurtleMachineSpeed;
    private javax.swing.JButton cmdExecute;
    private javax.swing.JButton cmdIwanttodrawmyownprogram;
    private javax.swing.JButton cmdLevelNext;
    private javax.swing.JButton cmdLevelPrevious;
    private javax.swing.JButton cmdLoad;
    private javax.swing.JButton cmdMenu;
    private javax.swing.JButton cmdSave;
    private javax.swing.JButton cmdStop;
    private graphprog.ImageList imageListChallenge;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu jPopupMenuTurtleEnvironment;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSplitPane jSplitPane;
    private javax.swing.JLabel lblExecutionError;
    private javax.swing.JLabel lblLevel;
    private javax.swing.JLabel lblLevel1;
    private javax.swing.JLabel lblMainPanelPositionCurseur;
    private javax.swing.JTextArea lblMission;
    private javax.swing.JLabel lblMissionFailed;
    private javax.swing.JLabel lblWhatdoyouwanttodraw;
    private graphprog.LogoTitlePanel logoTitlePanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuItem mnuChangeSpeed;
    private javax.swing.JRadioButtonMenuItem mnuTurtleInvisible;
    private javax.swing.JRadioButtonMenuItem mnuTurtleVisible;
    private javax.swing.JPanel panMission;
    private javax.swing.JPanel panel_all;
    private javax.swing.JPanel panel_level;
    private javax.swing.JPanel panel_menu;
    private javax.swing.JPanel panel_menu_challenge;
    private javax.swing.JPanel panel_topscreen;
    private javax.swing.JPanel paneltools_container;
    private graphprog.PanelToolsLevel1 paneltools_level1;
    private graphprog.PanelToolsLevel2 paneltools_level2;
    private graphprog.PanelToolsLevel3 paneltools_level3;
    private graphprog.PanelToolsLevel4 paneltools_level4;
    private graphprog.PanelToolsLevel6 paneltools_level6;
    private javax.swing.JPanel program_part;
    private javax.swing.JPanel programing_panel_all;
    private javax.swing.JToolBar toobar_execution;
    private javax.swing.JToolBar toolbar_level;
    private javax.swing.JToolBar toolbar_loadsave;
    private javax.swing.JToolBar toolbar_menu;
    private javax.swing.JToolBar toolbar_quit;
    private javax.swing.JPanel turtle_environment;
    // End of variables declaration//GEN-END:variables

    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;

    private JDialog aboutBox;
}
