/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphprog;

import java.util.Hashtable;

/**
 *
 * @author proprietaire
 */
public class Machine_Turtle_Information {
    private Brick brick_return;
    
    private Hashtable<String, Integer> variables;
    

    public Brick getBrick_return() {
        return brick_return;
    }


    private int ForCount = 0;
    private int ForCountAtTheBeginning = 0;

    public int getForCount() {
        return ForCount;
    }
    
    public int getForCountAtTheBeginning() {
        return ForCountAtTheBeginning;
    }

    public void setForCountAtTheBeginning(int ForCount) {
        this.ForCount = ForCount;
        this.ForCountAtTheBeginning = ForCount;
    }
    
    
    public void decForCount()
    {
        ForCount -= 1; 
    }

    Machine_Turtle_Information(Brick brick_return)
    {
        this.brick_return = brick_return;
        variables = new Hashtable<String, Integer>();

    }


    public void variable_setvalue(String variable_name, int variable_value)
    {
        variables.put(variable_name, variable_value);
    }
    
    
    public int variable_getvalue(String variable_name)
    {
        return variables.get(variable_name);
    }
    
    
    public boolean variable_isdefined(String variable_name)
    {
        return variables.containsKey(variable_name);
    }
}
