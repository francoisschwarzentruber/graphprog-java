package graphprog;


import java.net.URL;
import javax.swing.ImageIcon;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author proprietaire
 */
public class Images {
      static ImageIcon get(String ressourcename)
      {
          Images img;
          img = new Images();
          
          URL url = img.getClass().getResource(ressourcename);
          System.out.println("I am loading the image (url: " + url + ", file: " + ressourcename + ")");
          return new ImageIcon(url);
      }

}
